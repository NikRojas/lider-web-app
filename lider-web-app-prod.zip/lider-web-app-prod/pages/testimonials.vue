<template>
  <main class="testimonials">
    <Banner :banner="page.data.content[
                  page.data.content.findIndex((x) => x.name === 'Banner')
                ].content_formatted.includes('image') ? 
                page.data.content[
                  page.data.content.findIndex((x) => x.name === 'Banner')
                ].content.find((x) => x.field === 'image').value : ''" :title="page.data.content[page.data.content.findIndex(x => x.name === 'Banner')].content_formatted.includes('title')
            && page.data.content[page.data.content.findIndex(el => el.name === 'Banner')].content.find(x => x.field === 'title')['value_'+$i18n.locale] ?
            page.data.content[page.data.content.findIndex(el => el.name === 'Banner')].content.find(x => x.field === 'title')['value_'+$i18n.locale]
            : ''">
    </Banner>

    <section class="section section-testimoniales">
      <div class="container">
        <div class="text-center wow fadeInUp">
             <h2 v-if="page.data.content[page.data.content.findIndex(x => x.name === 'Conoce lo que dicen nuestros vecinos Líder')].content_formatted.includes('title')
            && page.data.content[page.data.content.findIndex(el => el.name === 'Conoce lo que dicen nuestros vecinos Líder')].content.find(x => x.field === 'title')['value_'+$i18n.locale]"
            ><b>{{ page.data.content[page.data.content.findIndex(el => el.name === 'Conoce lo que dicen nuestros vecinos Líder')].content.find(x => x.field === 'title')['value_'+$i18n.locale] }}</b>
          </h2>
              <div v-if="page.data.content[page.data.content.findIndex(x => x.name === 'Conoce lo que dicen nuestros vecinos Líder')].content_formatted.includes('description')
            && page.data.content[page.data.content.findIndex(el => el.name === 'Conoce lo que dicen nuestros vecinos Líder')].content.find(x => x.field === 'description')['value_'+$i18n.locale]"
                      v-html="
                        page.data.content[page.data.content.findIndex(el => el.name === 'Conoce lo que dicen nuestros vecinos Líder')].content.find(x => x.field === 'description')['value_'+$i18n.locale]
                      "></div>
          <br />
        </div>
        <div
          class="grid-3col wow fadeInUp"
          v-if="page.data.testimonials.data.length"
        >
          <div
            class="card"
            :class="el.type_video ? 'card-testimonio1' : 'card-testimonio2'"
            v-for="el in page.data.testimonials.data"
            :key="el.i"
          >
            <div class="card-video" v-if="el.type_video">
              <img
                class="lazyload"
                :data-src="storageUrl + '/img/testimonials/' + el.image"
                :alt="el['title_' + $i18n.locale] + ' ' + el.project"
              />
              <a
                class="fancybox"
                data-fancybox="Testimonios"
                v-if="el.url_video"
                :href="el.url_video"
                ><i class="flaticon-boton-de-play"></i
              ></a>
            </div>
            <div v-else class="content">
              <img
                :data-src="require('~/assets/img/icon-testimonial.png')"
                class="lazyload"
                :alt="'Quote ' + el['title_' + $i18n.locale] + ' ' + el.project"
              />
              <div v-html="el['description_' + $i18n.locale]"></div>
            </div>
            <h5>
              <b>- {{ el["title_" + $i18n.locale] }}</b>
            </h5>
            <strong>{{ el.project }}</strong>
          </div>

          <template v-if="loadingMore">
            <div class="card" v-for="(el, i) in 3" :key="'test' + i">
              <PuSkeleton height="200px"></PuSkeleton>
            </div>
          </template>
        </div>

        <div
          class="text-center"
          v-if="page.data.testimonials.last_page != pageActive"
        >
          <button
            :class="loadingMore ? 'btn--opacity' : ''"
            type="button"
            @click="paginateTestimonials"
            :disabled="loadingMore"
            class="btn"
          >
            {{ loadingMore ? $t("Cargando")+"..." : $t("Más testimonios") }}
          </button>
        </div>
      </div>
    </section>
  </main>
</template>
<script>
if (process.client) {
  require("/static/js/jq.fancybox.min.js");
}
import "/static/css/jq.fancybox.min.css";
import Banner from "../components/Banner";
export default {
  components:{
    Banner
  },
  async asyncData({ params, $axios, app }) {
    let { data } = await $axios.get("/api/page/testimonials", {
      params: { locale: app.i18n.locale },
    });
    return { page: data };
  },
  nuxtI18n: {
    paths: {
      en: "/testimonials",
      es: "/testimoniales",
    },
  },
  head() {
    return { 
      htmlAttrs: {
        lang: this.$i18n.locale == 'en' ? this.$i18n.locale+'_US' : this.$i18n.locale+'_PE'
      },
      title: this.page.data.page["title_"+this.$i18n.locale] ? this.page.data.page["title_"+this.$i18n.locale] : "",
      meta: [
        {
          hid: "description",
          name: "description",
          content: this.page.data.page['seo_description_'+this.$i18n.locale]
            ? this.page.data.page['seo_description_'+this.$i18n.locale]
            : ""
        },
        {
          itemprop: "name",
          content: this.page.data.page['title_'+this.$i18n.locale] ? this.page.data.page['title_'+this.$i18n.locale] : ""
        },
        {
          itemprop: "description",
          content: this.page.data.page['seo_description_'+this.$i18n.locale]
            ? this.page.data.page['seo_description_'+this.$i18n.locale]
            : ""
        },
        {
          itemprop: "image",
          content: this.page.data.page['seo_image']
            ? process.env.STORAGE_URL +
              "/img/pages/" +
              this.page.data.page['seo_image']
            : ""
        },
        {
          name: "keywords",
          content: this.page.data.page['seo_keywords_'+this.$i18n.locale]
            ? this.page.data.page['seo_keywords_'+this.$i18n.locale]
            : ""
        },
        { name: "og:url", content: process.env.BASE_URL+this.$route.path  },
        { name: "og:type", content: "website" },
        {
          name: "og:title",
          content: this.page.data.page['title_'+this.$i18n.locale] ? this.page.data.page['title_'+this.$i18n.locale] : ""
        },
        {
          name: "og:description",
          content: this.page.data.page['seo_description_'+this.$i18n.locale]
            ? this.page.data.page['seo_description_'+this.$i18n.locale]
            : ""
        },
        {
          name: "og:image",
          content: this.page.data.page['seo_image']
            ? process.env.STORAGE_URL +
              "/img/pages/" +
              this.page.data.page['seo_image']
            : ""
        },
        { name: "twitter:card", content: "summary_large_image" },
        {
          name: "twitter:title",
          content: this.page.data.page['title_'+this.$i18n.locale] ? this.page.data.page['title_'+this.$i18n.locale] : ""
        },
        {
          name: "twitter:description",
          content: this.page.data.page['seo_description_'+this.$i18n.locale]
            ? this.page.data.page['seo_description_'+this.$i18n.locale]
            : ""
        },
        {
          name: "twitter:image",
          content: this.page.data.page['seo_image']
            ? process.env.STORAGE_URL +
              "/img/pages/" +
              this.page.data.page['seo_image']
            : ""
        }
      ]
    };
  },
  data() {
    return {
      page: {},
      loadingMore: false,
      pageActive: 1,
      storageUrl: process.env.STORAGE_URL,
    };
  },
  methods: {
    paginateTestimonials() {
      this.loadingMore = true;
      this.$axios
        .$get("/api/paginate/testimonials", {
          params: {
            locale: this.$i18n.locale,
            page: this.pageActive + 1,
          },
        })
        .then((response) => {
          if (response.data.length) {
            this.pageActive += 1;
            this.page.data.testimonials.data.push(...response.data);
          }

          this.loadingMore = false;
        });
    },
  },
  mounted() {
    $(document).ready(function () {
      $(".fancybox").fancybox();
      });
  },
};
</script>