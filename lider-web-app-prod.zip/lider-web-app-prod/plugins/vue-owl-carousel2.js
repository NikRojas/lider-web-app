import Vue from 'vue'
//import carousel from 'vue-owl-carousel2'
import carousel from 'vue-owl-carousel'

Vue.component('carousel', carousel);
