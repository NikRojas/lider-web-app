import Vue from 'vue'
import device from "vue-device-detector"
Vue.use(device)