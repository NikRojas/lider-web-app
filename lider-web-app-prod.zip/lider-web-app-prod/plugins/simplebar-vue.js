import Vue from 'vue'
import simplebar from 'simplebar-vue';
import 'simplebar/dist/simplebar.min.css';
 
Vue.component('simplebar', simplebar);