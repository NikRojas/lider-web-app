import Vue from 'vue';
import Skeleton from 'vue-loading-skeleton';

Vue.use(Skeleton)