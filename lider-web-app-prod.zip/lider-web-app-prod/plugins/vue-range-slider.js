import Vue from 'vue'
import 'vue-range-component-fixed/dist/vue-range-slider.css';
import VueRangeSlider from 'vue-range-component-fixed'

Vue.component('vue-range-slider', VueRangeSlider);
//Vue.use(VueRangeSlider)