<template>
  <div class="wrapper_email">
    <client-only>
      <div style="" class="inner-email">
        <div
          style="
            -moz-box-sizing: border-box;
            -ms-text-size-adjust: 100%;
            -webkit-box-sizing: border-box;
            -webkit-text-size-adjust: 100%;
            margin: 0;
            background: #f9f9f9;
            box-sizing: border-box;
            color: #0a0a0a;
            font-family: Helvetica, Arial, sans-serif;
            font-size: 16px;
            font-weight: 400;
            line-height: 1.3;
            margin: 0;
            min-width: 100%;
            padding: 0;
            padding-bottom: 0;
            padding-left: 0;
            padding-right: 0;
            padding-top: 0;
            text-align: left;
            width: 100% !important;
          "
        >
          <span
            class="preheader"
            style="
              color: #f9f9f9;
              display: none !important;
              font-size: 1px;
              line-height: 1px;
              max-height: 0;
              max-width: 0;
              mso-hide: all !important;
              opacity: 0;
              overflow: hidden;
              visibility: hidden;
            "
          ></span>
          <table
            class="div"
            style="
              margin: 0;
              background: #f9f9f9;
              border-collapse: collapse;
              border-spacing: 0;
              color: #0a0a0a;
              font-family: Helvetica, Arial, sans-serif;
              font-size: 16px;
              font-weight: 400;
              height: 100%;
              line-height: 1.3;
              margin: 0;
              padding-bottom: 0;
              padding-left: 0;
              padding-right: 0;
              padding-top: 0;
              text-align: left;
              vertical-align: top;
              width: 100%;
            "
          >
            <tr
              style="
                padding-bottom: 0;
                padding-left: 0;
                padding-right: 0;
                padding-top: 0;
                text-align: left;
                vertical-align: top;
              "
            >
              <td
                class="center"
                align="center"
                valign="top"
                style="
                  -moz-hyphens: auto;
                  -webkit-hyphens: auto;
                  margin: 0;
                  border-collapse: collapse !important;
                  color: #0a0a0a;
                  font-family: Helvetica, Arial, sans-serif;
                  font-size: 16px;
                  font-weight: 400;
                  hyphens: auto;
                  line-height: 1.3;
                  margin: 0;
                  padding-bottom: 0;
                  padding-left: 0;
                  padding-right: 0;
                  padding-top: 0;
                  text-align: left;
                  vertical-align: top;
                  word-wrap: break-word;
                "
              >
                <!--<center style="min-width: 580px; width: 100%">-->
                <center style="width: 100%">
                  <table
                    align="center"
                    class="spacer float-center"
                    style="
                      margin: 0 auto;
                      border-collapse: collapse;
                      border-spacing: 0;
                      float: none;
                      margin: 0 auto;
                      padding-bottom: 0;
                      padding-left: 0;
                      padding-right: 0;
                      padding-top: 0;
                      text-align: center;
                      vertical-align: top;
                      width: 100%;
                    "
                  >
                    <tbody>
                      <tr
                        style="
                          padding-bottom: 0;
                          padding-left: 0;
                          padding-right: 0;
                          padding-top: 0;
                          text-align: left;
                          vertical-align: top;
                        "
                      >
                        <td
                          height="32"
                          style="
                            -moz-hyphens: auto;
                            -webkit-hyphens: auto;
                            margin: 0;
                            border-collapse: collapse !important;
                            color: #0a0a0a;
                            font-family: Helvetica, Arial, sans-serif;
                            font-size: 32px;
                            font-weight: 400;
                            hyphens: auto;
                            line-height: 32px;
                            margin: 0;
                            mso-line-height-rule: exactly;
                            padding-bottom: 0;
                            padding-left: 0;
                            padding-right: 0;
                            padding-top: 0;
                            text-align: left;
                            vertical-align: top;
                            word-wrap: break-word;
                          "
                        >
                          &nbsp;
                        </td>
                      </tr>
                    </tbody>
                  </table>
                  <!--<table
                    align="center"
                    class="container float-center"
                    style="
                      margin: 0 auto;
                      background: #fefefe;
                      border-collapse: collapse;
                      border-spacing: 0;
                      float: none;
                      margin: 0 auto;
                      padding-bottom: 0;
                      padding-left: 0;
                      padding-right: 0;
                      padding-top: 0;
                      text-align: center;
                      vertical-align: top;
                      width: 580px;
                    "
                  >-->
                  <table
                    align="center"
                    class="container float-center"
                    style="
                      margin: 0 auto;
                      background: #fefefe;
                      border-collapse: collapse;
                      border-spacing: 0;
                      float: none;
                      margin: 0 auto;
                      padding-bottom: 0;
                      padding-left: 0;
                      padding-right: 0;
                      padding-top: 0;
                      text-align: center;
                      vertical-align: top;
                    "
                  >
                    <tbody>
                      <tr
                        style="
                          padding-bottom: 0;
                          padding-left: 0;
                          padding-right: 0;
                          padding-top: 0;
                          text-align: left;
                          vertical-align: top;
                        "
                      >
                        <td
                          style="
                            -moz-hyphens: auto;
                            -webkit-hyphens: auto;
                            margin: 0;
                            border-collapse: collapse !important;
                            color: #0a0a0a;
                            font-family: Helvetica, Arial, sans-serif;
                            font-size: 16px;
                            font-weight: 400;
                            hyphens: auto;
                            line-height: 1.3;
                            margin: 0;
                            padding-bottom: 0;
                            padding-left: 0;
                            padding-right: 0;
                            padding-top: 0;
                            text-align: left;
                            vertical-align: top;
                            word-wrap: break-word;
                          "
                        >
                          <table
                            class="spacer"
                            style="
                              border-collapse: collapse;
                              border-spacing: 0;
                              padding-bottom: 0;
                              padding-left: 0;
                              padding-right: 0;
                              padding-top: 0;
                              text-align: left;
                              vertical-align: top;
                              width: 100%;
                            "
                          >
                            <tbody>
                              <tr
                                style="
                                  padding-bottom: 0;
                                  padding-left: 0;
                                  padding-right: 0;
                                  padding-top: 0;
                                  text-align: left;
                                  vertical-align: top;
                                "
                              >
                                <td
                                  height="24"
                                  style="
                                    -moz-hyphens: auto;
                                    -webkit-hyphens: auto;
                                    margin: 0;
                                    border-collapse: collapse !important;
                                    color: #0a0a0a;
                                    font-family: Helvetica, Arial, sans-serif;
                                    font-size: 24px;
                                    font-weight: 400;
                                    hyphens: auto;
                                    line-height: 24px;
                                    margin: 0;
                                    mso-line-height-rule: exactly;
                                    padding-bottom: 0;
                                    padding-left: 0;
                                    padding-right: 0;
                                    padding-top: 0;
                                    text-align: left;
                                    vertical-align: top;
                                    word-wrap: break-word;
                                  "
                                >
                                  &nbsp;
                                </td>
                              </tr>
                            </tbody>
                          </table>
                          <table
                            class="row"
                            style="
                              max-width: 600px;
                              border-collapse: collapse;
                              border-spacing: 0;
                              display: table;
                              padding: 0;
                              padding-bottom: 0;
                              padding-left: 0;
                              padding-right: 0;
                              padding-top: 0;
                              position: relative;
                              text-align: left;
                              vertical-align: top;
                              width: 100%;
                            "
                          >
                            <tbody>
                              <tr
                                style="
                                  padding-bottom: 0;
                                  padding-left: 0;
                                  padding-right: 0;
                                  padding-top: 0;
                                  text-align: left;
                                  vertical-align: top;
                                "
                              >
                                <th
                                  class="small-6 large-6 columns first"
                                  style="
                                    -moz-hyphens: auto;
                                    -webkit-hyphens: auto;
                                    margin: 0 auto;
                                    border-collapse: collapse !important;
                                    color: #0a0a0a;
                                    font-family: Helvetica, Arial, sans-serif;
                                    font-size: 16px;
                                    font-weight: 400;
                                    hyphens: auto;
                                    line-height: 1.3;
                                    margin: 0 auto;
                                    padding-bottom: 16px;
                                    padding-left: 30px;
                                    padding-right: 15px;
                                    padding-top: 0;
                                    text-align: left;
                                    vertical-align: middle;
                                    width: 260px;
                                    word-wrap: break-word;
                                  "
                                >
                                  <table
                                    style="
                                      border-collapse: collapse;
                                      border-spacing: 0;
                                      padding-bottom: 0;
                                      padding-left: 0;
                                      padding-right: 0;
                                      padding-top: 0;
                                      text-align: left;
                                      vertical-align: top;
                                      width: 100%;
                                    "
                                  >
                                    <tbody>
                                      <tr
                                        style="
                                          padding-bottom: 0;
                                          padding-left: 0;
                                          padding-right: 0;
                                          padding-top: 0;
                                          text-align: left;
                                          vertical-align: top;
                                        "
                                      >
                                        <th
                                          style="
                                            -moz-hyphens: auto;
                                            -webkit-hyphens: auto;
                                            margin: 0;
                                            border-collapse: collapse !important;
                                            color: #0a0a0a;
                                            font-family: Helvetica, Arial,
                                              sans-serif;
                                            font-size: 16px;
                                            font-weight: 400;
                                            hyphens: auto;
                                            line-height: 1.3;
                                            margin: 0;
                                            padding-bottom: 0;
                                            padding-left: 0;
                                            padding-right: 0;
                                            padding-top: 0;
                                            text-align: left;
                                            vertical-align: top;
                                            word-wrap: break-word;
                                          "
                                        >
                                          <!--<img
                                            height="45"
                                            :src="storageUrl + '/img/logo.png'"
                                            alt
                                            style="
                                              -ms-interpolation-mode: bicubic;
                                              clear: both;
                                              display: block;
                                              max-width: 100%;
                                              outline: 0;
                                              text-decoration: none;
                                              width: auto;
                                            "
                                          />-->
                                        </th>
                                      </tr>
                                    </tbody>
                                  </table>
                                </th>
                                <th
                                  class="small-6 large-6 columns last"
                                  style="
                                    -moz-hyphens: auto;
                                    -webkit-hyphens: auto;
                                    margin: 0 auto;
                                    border-collapse: collapse !important;
                                    color: #0a0a0a;
                                    font-family: Helvetica, Arial, sans-serif;
                                    font-size: 16px;
                                    font-weight: 400;
                                    hyphens: auto;
                                    line-height: 1.3;
                                    margin: 0 auto;
                                    padding-bottom: 16px;
                                    padding-left: 15px;
                                    padding-right: 30px;
                                    padding-top: 0;
                                    text-align: left;
                                    vertical-align: middle;
                                    width: 260px;
                                    word-wrap: break-word;
                                  "
                                >
                                  <table
                                    style="
                                      border-collapse: collapse;
                                      border-spacing: 0;
                                      padding-bottom: 0;
                                      padding-left: 0;
                                      padding-right: 0;
                                      padding-top: 0;
                                      text-align: left;
                                      vertical-align: top;
                                      width: 100%;
                                    "
                                  >
                                    <tbody>
                                      <tr
                                        style="
                                          padding-bottom: 0;
                                          padding-left: 0;
                                          padding-right: 0;
                                          padding-top: 0;
                                          text-align: left;
                                          vertical-align: top;
                                        "
                                      >
                                        <th
                                          style="
                                            -moz-hyphens: auto;
                                            -webkit-hyphens: auto;
                                            margin: 0;
                                            border-collapse: collapse !important;
                                            color: #0a0a0a;
                                            font-family: Helvetica, Arial,
                                              sans-serif;
                                            font-size: 16px;
                                            font-weight: 400;
                                            hyphens: auto;
                                            line-height: 1.3;
                                            margin: 0;
                                            padding-bottom: 0;
                                            padding-left: 0;
                                            padding-right: 0;
                                            padding-top: 0;
                                            text-align: left;
                                            vertical-align: top;
                                            word-wrap: break-word;
                                          "
                                        >
                                          <p
                                            style="
                                              margin: 0;
                                              margin-bottom: 10px;
                                              color: #0a0a0a;
                                              font-family: Helvetica, Arial,
                                                sans-serif;
                                              font-size: 14px;
                                              font-weight: 400;
                                              line-height: 1.3;
                                              margin: 0;
                                              margin-bottom: 0;
                                              padding-bottom: 0;
                                              padding-left: 0;
                                              padding-right: 0;
                                              padding-top: 0;
                                              text-align: right;
                                            "
                                            class="text-right"
                                          >
                                            {{
                                              page.data.lead
                                                .created_at_format_email
                                            }}
                                          </p>
                                        </th>
                                      </tr>
                                    </tbody>
                                  </table>
                                </th>
                              </tr>
                            </tbody>
                          </table>
                          <table
                            class="row"
                            style="
                              max-width: 600px;
                              border-collapse: collapse;
                              border-spacing: 0;
                              display: table;
                              padding: 0;
                              padding-bottom: 0;
                              padding-left: 0;
                              padding-right: 0;
                              padding-top: 0;
                              position: relative;
                              text-align: left;
                              vertical-align: top;
                              width: 100%;
                            "
                          >
                            <tbody>
                              <tr
                                style="
                                  padding-bottom: 0;
                                  padding-left: 0;
                                  padding-right: 0;
                                  padding-top: 0;
                                  text-align: left;
                                  vertical-align: top;
                                "
                              >
                                <th
                                  class="small-12 large-12 columns first last"
                                  style="
                                    -moz-hyphens: auto;
                                    -webkit-hyphens: auto;
                                    margin: 0 auto;
                                    border-collapse: collapse !important;
                                    color: #0a0a0a;
                                    font-family: Helvetica, Arial, sans-serif;
                                    font-size: 16px;
                                    font-weight: 400;
                                    hyphens: auto;
                                    line-height: 1.3;
                                    margin: 0 auto;
                                    padding-bottom: 16px;
                                    padding-left: 30px;
                                    padding-right: 30px;
                                    padding-top: 0;
                                    text-align: left;
                                    vertical-align: top;
                                    width: 550px;
                                    word-wrap: break-word;
                                  "
                                >
                                  <table
                                    style="
                                      border-collapse: collapse;
                                      border-spacing: 0;
                                      padding-bottom: 0;
                                      padding-left: 0;
                                      padding-right: 0;
                                      padding-top: 0;
                                      text-align: left;
                                      vertical-align: top;
                                      width: 100%;
                                    "
                                  >
                                    <tbody>
                                      <tr
                                        style="
                                          padding-bottom: 0;
                                          padding-left: 0;
                                          padding-right: 0;
                                          padding-top: 0;
                                          text-align: left;
                                          vertical-align: top;
                                        "
                                      >
                                        <th
                                          style="
                                            -moz-hyphens: auto;
                                            -webkit-hyphens: auto;
                                            margin: 0;
                                            border-collapse: collapse !important;
                                            color: #0a0a0a;
                                            font-family: Helvetica, Arial,
                                              sans-serif;
                                            font-size: 16px;
                                            font-weight: 400;
                                            hyphens: auto;
                                            line-height: 1.3;
                                            margin: 0;
                                            padding-bottom: 0;
                                            padding-left: 0;
                                            padding-right: 0;
                                            padding-top: 0;
                                            text-align: left;
                                            vertical-align: top;
                                            word-wrap: break-word;
                                          "
                                        >
                                          <table
                                            class="spacer"
                                            style="
                                              border-collapse: collapse;
                                              border-spacing: 0;
                                              padding-bottom: 0;
                                              padding-left: 0;
                                              padding-right: 0;
                                              padding-top: 0;
                                              text-align: left;
                                              vertical-align: top;
                                              width: 100%;
                                            "
                                          >
                                            <tbody>
                                              <tr
                                                style="
                                                  padding-bottom: 0;
                                                  padding-left: 0;
                                                  padding-right: 0;
                                                  padding-top: 0;
                                                  text-align: left;
                                                  vertical-align: top;
                                                "
                                              >
                                                <td
                                                  height="16"
                                                  style="
                                                    -moz-hyphens: auto;
                                                    -webkit-hyphens: auto;
                                                    margin: 0;
                                                    border-collapse: collapse !important;
                                                    color: #0a0a0a;
                                                    font-family: Helvetica,
                                                      Arial, sans-serif;
                                                    font-size: 16px;
                                                    font-weight: 400;
                                                    hyphens: auto;
                                                    line-height: 16px;
                                                    margin: 0;
                                                    mso-line-height-rule: exactly;
                                                    padding-bottom: 0;
                                                    padding-left: 0;
                                                    padding-right: 0;
                                                    padding-top: 0;
                                                    text-align: left;
                                                    vertical-align: top;
                                                    word-wrap: break-word;
                                                  "
                                                >
                                                  &nbsp;
                                                </td>
                                              </tr>
                                            </tbody>
                                          </table>
                                          <h5
                                            class="text-primary"
                                            style="
                                              margin: 0;
                                              margin-bottom: 10px;
                                              color: #0b6fa6;
                                              font-family: Helvetica, Arial,
                                                sans-serif;
                                              font-size: 20px;
                                              font-weight: 400;
                                              line-height: 1.3;
                                              margin: 0;
                                              margin-bottom: 10px;
                                              padding-bottom: 0;
                                              padding-left: 0;
                                              padding-right: 0;
                                              padding-top: 0;
                                              text-align: left;
                                              word-wrap: normal;
                                            "
                                          >
                                            <strong
                                              >Gracias por cotizar con
                                              nosotros</strong
                                            >
                                          </h5>
                                          <table
                                            class="spacer"
                                            style="
                                              border-collapse: collapse;
                                              border-spacing: 0;
                                              padding-bottom: 0;
                                              padding-left: 0;
                                              padding-right: 0;
                                              padding-top: 0;
                                              text-align: left;
                                              vertical-align: top;
                                              width: 100%;
                                            "
                                          >
                                            <tbody>
                                              <tr
                                                style="
                                                  padding-bottom: 0;
                                                  padding-left: 0;
                                                  padding-right: 0;
                                                  padding-top: 0;
                                                  text-align: left;
                                                  vertical-align: top;
                                                "
                                              >
                                                <td
                                                  height="12"
                                                  style="
                                                    -moz-hyphens: auto;
                                                    -webkit-hyphens: auto;
                                                    margin: 0;
                                                    border-collapse: collapse !important;
                                                    color: #0a0a0a;
                                                    font-family: Helvetica,
                                                      Arial, sans-serif;
                                                    font-size: 12px;
                                                    font-weight: 400;
                                                    hyphens: auto;
                                                    line-height: 12px;
                                                    margin: 0;
                                                    mso-line-height-rule: exactly;
                                                    padding-bottom: 0;
                                                    padding-left: 0;
                                                    padding-right: 0;
                                                    padding-top: 0;
                                                    text-align: left;
                                                    vertical-align: top;
                                                    word-wrap: break-word;
                                                  "
                                                >
                                                  &nbsp;
                                                </td>
                                              </tr>
                                            </tbody>
                                          </table>
                                          <p
                                            style="
                                              margin: 0;
                                              margin-bottom: 10px;
                                              color: #0a0a0a;
                                              font-family: Helvetica, Arial,
                                                sans-serif;
                                              font-size: 16px;
                                              font-weight: 400;
                                              line-height: 1.3;
                                              margin: 0;
                                              margin-bottom: 10px;
                                              padding-bottom: 0;
                                              padding-left: 0;
                                              padding-right: 0;
                                              padding-top: 0;
                                              text-align: left;
                                            "
                                          >
                                            <!--Estimado/a-->
                                            Hola
                                            <strong>{{ page.data.lead.first_name }}</strong>,
                                          </p>
                                          <p
                                            style="
                                              margin: 0;
                                              margin-bottom: 10px;
                                              color: #0a0a0a;
                                              font-family: Helvetica, Arial,
                                                sans-serif;
                                              font-size: 16px;
                                              font-weight: 400;
                                              line-height: 1.3;
                                              margin: 0;
                                              margin-bottom: 10px;
                                              padding-bottom: 0;
                                              padding-left: 0;
                                              padding-right: 0;
                                              padding-top: 0;
                                              text-align: left;
                                            "
                                          >
                                            <!--A continuación te mostramos
                                            información sobre el proyecto y el
                                            depa que escogiste y como
                                            contactarte con nosotros para poder
                                            atender tus consulta.-->
                                            A continuación te mostramos información sobre el inmueble que escogiste en 
                                            <strong>
                                            {{
                                              page.data.lead.project_rel.name_es
                                            }} - DISTRITO
                                            </strong>
                                          </p>
                                          <table
                                            class="spacer"
                                            style="
                                              border-collapse: collapse;
                                              border-spacing: 0;
                                              padding-bottom: 0;
                                              padding-left: 0;
                                              padding-right: 0;
                                              padding-top: 0;
                                              text-align: left;
                                              vertical-align: top;
                                              width: 100%;
                                            "
                                          >
                                            <tbody>
                                              <tr
                                                style="
                                                  padding-bottom: 0;
                                                  padding-left: 0;
                                                  padding-right: 0;
                                                  padding-top: 0;
                                                  text-align: left;
                                                  vertical-align: top;
                                                "
                                              >
                                                <td
                                                  height="16"
                                                  style="
                                                    -moz-hyphens: auto;
                                                    -webkit-hyphens: auto;
                                                    margin: 0;
                                                    border-collapse: collapse !important;
                                                    color: #0a0a0a;
                                                    font-family: Helvetica,
                                                      Arial, sans-serif;
                                                    font-size: 16px;
                                                    font-weight: 400;
                                                    hyphens: auto;
                                                    line-height: 16px;
                                                    margin: 0;
                                                    mso-line-height-rule: exactly;
                                                    padding-bottom: 0;
                                                    padding-left: 0;
                                                    padding-right: 0;
                                                    padding-top: 0;
                                                    text-align: left;
                                                    vertical-align: top;
                                                    word-wrap: break-word;
                                                  "
                                                >
                                                  &nbsp;
                                                </td>
                                              </tr>
                                            </tbody>
                                          </table>
                                          <table
                                            class="callout"
                                            style="
                                              margin-bottom: 16px;
                                              border-collapse: collapse;
                                              border-spacing: 0;
                                              margin-bottom: 16px;
                                              padding-bottom: 0;
                                              padding-left: 0;
                                              padding-right: 0;
                                              padding-top: 0;
                                              text-align: left;
                                              vertical-align: top;
                                              width: 100%;
                                            "
                                          >
                                            <tbody>
                                              <tr
                                                style="
                                                  padding-bottom: 0;
                                                  padding-left: 0;
                                                  padding-right: 0;
                                                  padding-top: 0;
                                                  text-align: left;
                                                  vertical-align: top;
                                                "
                                              >
                                                <th
                                                  class="callout-inner callout-project"
                                                  style="
                                                    -moz-hyphens: auto;
                                                    -webkit-hyphens: auto;
                                                    margin: 0;
                                                    background: #f9f9f9;
                                                    border: 0 !important;
                                                    border-collapse: collapse !important;
                                                    color: #0a0a0a;
                                                    font-family: Helvetica,
                                                      Arial, sans-serif;
                                                    font-size: 16px;
                                                    font-weight: 400;
                                                    hyphens: auto;
                                                    line-height: 1.3;
                                                    margin: 0;
                                                    padding: 1rem !important;
                                                    padding-bottom: 0;
                                                    padding-left: 0;
                                                    padding-right: 0;
                                                    padding-top: 0;
                                                    text-align: left;
                                                    vertical-align: top;
                                                    width: 100%;
                                                    word-wrap: break-word;
                                                  "
                                                >
                                                  <table
                                                    class="spacer"
                                                    style="
                                                      border-collapse: collapse;
                                                      border-spacing: 0;
                                                      padding-bottom: 0;
                                                      padding-left: 0;
                                                      padding-right: 0;
                                                      padding-top: 0;
                                                      text-align: left;
                                                      vertical-align: top;
                                                      width: 100%;
                                                    "
                                                  >
                                                    <tbody>
                                                      <tr
                                                        style="
                                                          padding-bottom: 0;
                                                          padding-left: 0;
                                                          padding-right: 0;
                                                          padding-top: 0;
                                                          text-align: left;
                                                          vertical-align: top;
                                                        "
                                                      >
                                                        <td
                                                          height="16"
                                                          style="
                                                            -moz-hyphens: auto;
                                                            -webkit-hyphens: auto;
                                                            margin: 0;
                                                            border-collapse: collapse !important;
                                                            color: #0a0a0a;
                                                            font-family: Helvetica,
                                                              Arial, sans-serif;
                                                            font-size: 16px;
                                                            font-weight: 400;
                                                            hyphens: auto;
                                                            line-height: 16px;
                                                            margin: 0;
                                                            mso-line-height-rule: exactly;
                                                            padding-bottom: 0;
                                                            padding-left: 0;
                                                            padding-right: 0;
                                                            padding-top: 0;
                                                            text-align: left;
                                                            vertical-align: top;
                                                            word-wrap: break-word;
                                                          "
                                                        >
                                                          &nbsp;
                                                        </td>
                                                      </tr>
                                                    </tbody>
                                                  </table>
                                                  <p
                                                    style="
                                                      margin: 0;
                                                      margin-bottom: 10px;
                                                      color: #0a0a0a;
                                                      font-family: Helvetica,
                                                        Arial, sans-serif;
                                                      font-size: 16px;
                                                      font-weight: 400;
                                                      line-height: 1.3;
                                                      margin: 0;
                                                      margin-bottom: 10px;
                                                      padding-bottom: 0;
                                                      padding-left: 0;
                                                      padding-right: 0;
                                                      padding-top: 0;
                                                      text-align: left;
                                                    "
                                                  >
                                                    <span
                                                      class="project-status"
                                                      style="
                                                        background-color: #f15f23;
                                                        color: #fff;
                                                        font-size: 14px;
                                                        font-weight: 500;
                                                        padding: 5px;
                                                        text-transform: uppercase;
                                                      "
                                                      >{{
                                                        page.data.lead
                                                          .project_rel
                                                          .status_rel[
                                                          "name_" + $i18n.locale
                                                        ]
                                                      }}</span
                                                    >
                                                  </p>
                                                  <table
                                                    class="spacer"
                                                    style="
                                                      border-collapse: collapse;
                                                      border-spacing: 0;
                                                      padding-bottom: 0;
                                                      padding-left: 0;
                                                      padding-right: 0;
                                                      padding-top: 0;
                                                      text-align: left;
                                                      vertical-align: top;
                                                      width: 100%;
                                                    "
                                                  >
                                                    <tbody>
                                                      <tr
                                                        style="
                                                          padding-bottom: 0;
                                                          padding-left: 0;
                                                          padding-right: 0;
                                                          padding-top: 0;
                                                          text-align: left;
                                                          vertical-align: top;
                                                        "
                                                      >
                                                        <td
                                                          height="12"
                                                          style="
                                                            -moz-hyphens: auto;
                                                            -webkit-hyphens: auto;
                                                            margin: 0;
                                                            border-collapse: collapse !important;
                                                            color: #0a0a0a;
                                                            font-family: Helvetica,
                                                              Arial, sans-serif;
                                                            font-size: 12px;
                                                            font-weight: 400;
                                                            hyphens: auto;
                                                            line-height: 12px;
                                                            margin: 0;
                                                            mso-line-height-rule: exactly;
                                                            padding-bottom: 0;
                                                            padding-left: 0;
                                                            padding-right: 0;
                                                            padding-top: 0;
                                                            text-align: left;
                                                            vertical-align: top;
                                                            word-wrap: break-word;
                                                          "
                                                        >
                                                          &nbsp;
                                                        </td>
                                                      </tr>
                                                    </tbody>
                                                  </table>
                                                  <table
                                                    class="row"
                                                    style="
                                                      border-collapse: collapse;
                                                      border-spacing: 0;
                                                      display: table;
                                                      padding: 0;
                                                      padding-bottom: 0;
                                                      padding-left: 0;
                                                      padding-right: 0;
                                                      padding-top: 0;
                                                      position: relative;
                                                      text-align: left;
                                                      vertical-align: top;
                                                      width: 100%;
                                                    "
                                                  >
                                                    <tbody>
                                                      <tr
                                                        style="
                                                          padding-bottom: 0;
                                                          padding-left: 0;
                                                          padding-right: 0;
                                                          padding-top: 0;
                                                          text-align: left;
                                                          vertical-align: top;
                                                        "
                                                      >
                                                        <th
                                                          class="small-12 large-12 columns first last"
                                                          style="
                                                            -moz-hyphens: auto;
                                                            -webkit-hyphens: auto;
                                                            margin: 0 auto;
                                                            border-collapse: collapse !important;
                                                            color: #0a0a0a;
                                                            font-family: Helvetica,
                                                              Arial, sans-serif;
                                                            font-size: 16px;
                                                            font-weight: 400;
                                                            hyphens: auto;
                                                            line-height: 1.3;
                                                            margin: 0 auto;
                                                            padding-bottom: 16px;
                                                            padding-left: 0 !important;
                                                            padding-right: 0 !important;
                                                            padding-top: 0;
                                                            text-align: left;
                                                            vertical-align: top;
                                                            width: 100%;
                                                            word-wrap: break-word;
                                                          "
                                                        >
                                                          <table
                                                            style="
                                                              border-collapse: collapse;
                                                              border-spacing: 0;
                                                              padding-bottom: 0;
                                                              padding-left: 0;
                                                              padding-right: 0;
                                                              padding-top: 0;
                                                              text-align: left;
                                                              vertical-align: top;
                                                              width: 100%;
                                                            "
                                                          >
                                                            <tbody>
                                                              <tr
                                                                style="
                                                                  padding-bottom: 0;
                                                                  padding-left: 0;
                                                                  padding-right: 0;
                                                                  padding-top: 0;
                                                                  text-align: left;
                                                                  vertical-align: top;
                                                                "
                                                              >
                                                                <th
                                                                  style="
                                                                    -moz-hyphens: auto;
                                                                    -webkit-hyphens: auto;
                                                                    margin: 0;
                                                                    border-collapse: collapse !important;
                                                                    color: #0a0a0a;
                                                                    font-family: Helvetica,
                                                                      Arial,
                                                                      sans-serif;
                                                                    font-size: 16px;
                                                                    font-weight: 400;
                                                                    hyphens: auto;
                                                                    line-height: 1.3;
                                                                    margin: 0;
                                                                    padding-bottom: 0;
                                                                    padding-left: 0;
                                                                    padding-right: 0;
                                                                    padding-top: 0;
                                                                    text-align: left;
                                                                    vertical-align: top;
                                                                    word-wrap: break-word;
                                                                  "
                                                                >
                                                                  <center
                                                                    style="
                                                                      min-width: none !important;
                                                                      width: 100%;
                                                                    "
                                                                  >
                                                                    <img
                                                                      :src="
                                                                        storageUrl +
                                                                        '/img/projects/' +
                                                                        page
                                                                          .data
                                                                          .lead
                                                                          .project_rel
                                                                          .logo_colour
                                                                      "
                                                                      height="50"
                                                                      alt
                                                                      align="center"
                                                                      class="float-center"
                                                                      style="
                                                                        -ms-interpolation-mode: bicubic;
                                                                        margin: 0
                                                                          auto;
                                                                        clear: both;
                                                                        display: block;
                                                                        float: none;
                                                                        margin: 0
                                                                          auto;
                                                                        max-width: 100%;
                                                                        outline: 0;
                                                                        text-align: center;
                                                                        text-decoration: none;
                                                                        width: auto;
                                                                      "
                                                                    />
                                                                  </center>
                                                                </th>
                                                                <th
                                                                  class="expander"
                                                                  style="
                                                                    -moz-hyphens: auto;
                                                                    -webkit-hyphens: auto;
                                                                    margin: 0;
                                                                    border-collapse: collapse !important;
                                                                    color: #0a0a0a;
                                                                    font-family: Helvetica,
                                                                      Arial,
                                                                      sans-serif;
                                                                    font-size: 16px;
                                                                    font-weight: 400;
                                                                    hyphens: auto;
                                                                    line-height: 1.3;
                                                                    margin: 0;
                                                                    padding: 0 !important;
                                                                    padding-bottom: 0;
                                                                    padding-left: 0;
                                                                    padding-right: 0;
                                                                    padding-top: 0;
                                                                    text-align: left;
                                                                    vertical-align: top;
                                                                    visibility: hidden;
                                                                    width: 0;
                                                                    word-wrap: break-word;
                                                                  "
                                                                ></th>
                                                              </tr>
                                                            </tbody>
                                                          </table>
                                                        </th>
                                                      </tr>
                                                    </tbody>
                                                  </table>
                                                  <table
                                                    class="spacer"
                                                    style="
                                                      border-collapse: collapse;
                                                      border-spacing: 0;
                                                      padding-bottom: 0;
                                                      padding-left: 0;
                                                      padding-right: 0;
                                                      padding-top: 0;
                                                      text-align: left;
                                                      vertical-align: top;
                                                      width: 100%;
                                                    "
                                                  >
                                                    <tbody>
                                                      <tr
                                                        style="
                                                          padding-bottom: 0;
                                                          padding-left: 0;
                                                          padding-right: 0;
                                                          padding-top: 0;
                                                          text-align: left;
                                                          vertical-align: top;
                                                        "
                                                      >
                                                        <td
                                                          height="12"
                                                          style="
                                                            -moz-hyphens: auto;
                                                            -webkit-hyphens: auto;
                                                            margin: 0;
                                                            border-collapse: collapse !important;
                                                            color: #0a0a0a;
                                                            font-family: Helvetica,
                                                              Arial, sans-serif;
                                                            font-size: 12px;
                                                            font-weight: 400;
                                                            hyphens: auto;
                                                            line-height: 12px;
                                                            margin: 0;
                                                            mso-line-height-rule: exactly;
                                                            padding-bottom: 0;
                                                            padding-left: 0;
                                                            padding-right: 0;
                                                            padding-top: 0;
                                                            text-align: left;
                                                            vertical-align: top;
                                                            word-wrap: break-word;
                                                          "
                                                        >
                                                          &nbsp;
                                                        </td>
                                                      </tr>
                                                    </tbody>
                                                  </table>
                                                  <div
                                                    v-if="
                                                      page.data.lead.project_rel
                                                        .excerpt_quotation
                                                    "
                                                    style="
                                                      margin: 0;
                                                      margin-bottom: 10px;
                                                      color: #0a0a0a;
                                                      font-family: Helvetica,
                                                        Arial, sans-serif;
                                                      font-size: 16px;
                                                      font-weight: 400;
                                                      line-height: 1.3;
                                                      margin: 0;
                                                      margin-bottom: 10px;
                                                      padding-bottom: 0;
                                                      padding-left: 0;
                                                      padding-right: 0;
                                                      padding-top: 0;
                                                      text-align: left;
                                                    "
                                                    v-html="
                                                      page.data.lead.project_rel
                                                        .excerpt_quotation
                                                    "
                                                  ></div>
                                                  <table
                                                    class="spacer"
                                                    style="
                                                      border-collapse: collapse;
                                                      border-spacing: 0;
                                                      padding-bottom: 0;
                                                      padding-left: 0;
                                                      padding-right: 0;
                                                      padding-top: 0;
                                                      text-align: left;
                                                      vertical-align: top;
                                                      width: 100%;
                                                    "
                                                  >
                                                    <tbody>
                                                      <tr
                                                        style="
                                                          padding-bottom: 0;
                                                          padding-left: 0;
                                                          padding-right: 0;
                                                          padding-top: 0;
                                                          text-align: left;
                                                          vertical-align: top;
                                                        "
                                                      >
                                                        <td
                                                          height="4"
                                                          style="
                                                            -moz-hyphens: auto;
                                                            -webkit-hyphens: auto;
                                                            margin: 0;
                                                            border-collapse: collapse !important;
                                                            color: #0a0a0a;
                                                            font-family: Helvetica,
                                                              Arial, sans-serif;
                                                            font-size: 4px;
                                                            font-weight: 400;
                                                            hyphens: auto;
                                                            line-height: 4px;
                                                            margin: 0;
                                                            mso-line-height-rule: exactly;
                                                            padding-bottom: 0;
                                                            padding-left: 0;
                                                            padding-right: 0;
                                                            padding-top: 0;
                                                            text-align: left;
                                                            vertical-align: top;
                                                            word-wrap: break-word;
                                                          "
                                                        >
                                                          &nbsp;
                                                        </td>
                                                      </tr>
                                                    </tbody>
                                                  </table>
                                                </th>
                                                <th
                                                  class="expander"
                                                  style="
                                                    -moz-hyphens: auto;
                                                    -webkit-hyphens: auto;
                                                    margin: 0;
                                                    border-collapse: collapse !important;
                                                    color: #0a0a0a;
                                                    font-family: Helvetica,
                                                      Arial, sans-serif;
                                                    font-size: 16px;
                                                    font-weight: 400;
                                                    hyphens: auto;
                                                    line-height: 1.3;
                                                    margin: 0;
                                                    padding: 0 !important;
                                                    padding-bottom: 0;
                                                    padding-left: 0;
                                                    padding-right: 0;
                                                    padding-top: 0;
                                                    text-align: left;
                                                    vertical-align: top;
                                                    visibility: hidden;
                                                    width: 0;
                                                    word-wrap: break-word;
                                                  "
                                                ></th>
                                              </tr>
                                            </tbody>
                                          </table>
                                        </th>
                                      </tr>
                                    </tbody>
                                  </table>
                                </th>
                              </tr>
                            </tbody>
                          </table>
                          <table
                            class="row"
                            style="
                              max-width: 600px;
                              border-collapse: collapse;
                              border-spacing: 0;
                              display: table;
                              padding: 0;
                              padding-bottom: 0;
                              padding-left: 0;
                              padding-right: 0;
                              padding-top: 0;
                              position: relative;
                              text-align: left;
                              vertical-align: top;
                              width: 100%;
                            "
                          >
                            <tbody>
                              <tr
                                style="
                                  padding-bottom: 0;
                                  padding-left: 0;
                                  padding-right: 0;
                                  padding-top: 0;
                                  text-align: left;
                                  vertical-align: top;
                                "
                              >
                                <th
                                  class="small-12 large-12 columns first last"
                                  style="
                                    -moz-hyphens: auto;
                                    -webkit-hyphens: auto;
                                    margin: 0 auto;
                                    border-collapse: collapse !important;
                                    color: #0a0a0a;
                                    font-family: Helvetica, Arial, sans-serif;
                                    font-size: 16px;
                                    font-weight: 400;
                                    hyphens: auto;
                                    line-height: 1.3;
                                    margin: 0 auto;
                                    padding-bottom: 16px;
                                    padding-left: 30px;
                                    padding-right: 30px;
                                    padding-top: 0;
                                    text-align: left;
                                    vertical-align: top;
                                    width: 550px;
                                    word-wrap: break-word;
                                  "
                                >
                                  <table
                                    style="
                                      border-collapse: collapse;
                                      border-spacing: 0;
                                      padding-bottom: 0;
                                      padding-left: 0;
                                      padding-right: 0;
                                      padding-top: 0;
                                      text-align: left;
                                      vertical-align: top;
                                      width: 100%;
                                    "
                                  >
                                    <tbody>
                                      <tr
                                        style="
                                          padding-bottom: 0;
                                          padding-left: 0;
                                          padding-right: 0;
                                          padding-top: 0;
                                          text-align: left;
                                          vertical-align: top;
                                        "
                                      >
                                        <th
                                          style="
                                            -moz-hyphens: auto;
                                            -webkit-hyphens: auto;
                                            margin: 0;
                                            border-collapse: collapse !important;
                                            color: #0a0a0a;
                                            font-family: Helvetica, Arial,
                                              sans-serif;
                                            font-size: 16px;
                                            font-weight: 400;
                                            hyphens: auto;
                                            line-height: 1.3;
                                            margin: 0;
                                            padding-bottom: 0;
                                            padding-left: 0;
                                            padding-right: 0;
                                            padding-top: 0;
                                            text-align: left;
                                            vertical-align: top;
                                            word-wrap: break-word;
                                          "
                                        >
                                          <h5
                                            class="text-primary"
                                            style="
                                              margin: 0;
                                              margin-bottom: 10px;
                                              color: #0b6fa6;
                                              font-family: Helvetica, Arial,
                                                sans-serif;
                                              font-size: 20px;
                                              font-weight: 400;
                                              line-height: 1.3;
                                              margin: 0;
                                              margin-bottom: 0;
                                              padding-bottom: 0;
                                              padding-left: 0;
                                              padding-right: 0;
                                              padding-top: 0;
                                              text-align: left;
                                              word-wrap: normal;
                                            "
                                          >
                                            <strong>Inmueble Elegido</strong>
                                          </h5>
                                        </th>
                                        <th
                                          class="expander"
                                          style="
                                            -moz-hyphens: auto;
                                            -webkit-hyphens: auto;
                                            margin: 0;
                                            border-collapse: collapse !important;
                                            color: #0a0a0a;
                                            font-family: Helvetica, Arial,
                                              sans-serif;
                                            font-size: 16px;
                                            font-weight: 400;
                                            hyphens: auto;
                                            line-height: 1.3;
                                            margin: 0;
                                            padding: 0 !important;
                                            padding-bottom: 0;
                                            padding-left: 0;
                                            padding-right: 0;
                                            padding-top: 0;
                                            text-align: left;
                                            vertical-align: top;
                                            visibility: hidden;
                                            width: 0;
                                            word-wrap: break-word;
                                          "
                                        ></th>
                                      </tr>
                                    </tbody>
                                  </table>
                                </th>
                              </tr>
                            </tbody>
                          </table>
                          <table
                            class="row"
                            style="
                              max-width: 600px;
                              border-collapse: collapse;
                              border-spacing: 0;
                              display: table;
                              padding: 0;
                              padding-bottom: 0;
                              padding-left: 0;
                              padding-right: 0;
                              padding-top: 0;
                              position: relative;
                              text-align: left;
                              vertical-align: top;
                              width: 100%;
                            "
                          >
                            <tbody>
                              <tr
                                style="
                                  padding-bottom: 0;
                                  padding-left: 0;
                                  padding-right: 0;
                                  padding-top: 0;
                                  text-align: left;
                                  vertical-align: top;
                                "
                              >
                                <th
                                  class="small-12 large-12 columns first last"
                                  style="
                                    -moz-hyphens: auto;
                                    -webkit-hyphens: auto;
                                    margin: 0 auto;
                                    border-collapse: collapse !important;
                                    color: #0a0a0a;
                                    font-family: Helvetica, Arial, sans-serif;
                                    font-size: 16px;
                                    font-weight: 400;
                                    hyphens: auto;
                                    line-height: 1.3;
                                    margin: 0 auto;
                                    padding-bottom: 16px;
                                    padding-left: 30px;
                                    padding-right: 30px;
                                    padding-top: 0;
                                    text-align: left;
                                    vertical-align: top;
                                    width: 550px;
                                    word-wrap: break-word;
                                  "
                                >
                                  <table
                                    style="
                                      border-collapse: collapse;
                                      border-spacing: 0;
                                      padding-bottom: 0;
                                      padding-left: 0;
                                      padding-right: 0;
                                      padding-top: 0;
                                      text-align: left;
                                      vertical-align: top;
                                      width: 100%;
                                    "
                                  >
                                    <tbody>
                                      <tr
                                        style="
                                          padding-bottom: 0;
                                          padding-left: 0;
                                          padding-right: 0;
                                          padding-top: 0;
                                          text-align: left;
                                          vertical-align: top;
                                        "
                                      >
                                        <th
                                          style="
                                            -moz-hyphens: auto;
                                            -webkit-hyphens: auto;
                                            margin: 0;
                                            border-collapse: collapse !important;
                                            color: #0a0a0a;
                                            font-family: Helvetica, Arial,
                                              sans-serif;
                                            font-size: 16px;
                                            font-weight: 400;
                                            hyphens: auto;
                                            line-height: 1.3;
                                            margin: 0;
                                            padding-bottom: 0;
                                            padding-left: 0;
                                            padding-right: 0;
                                            padding-top: 0;
                                            text-align: left;
                                            vertical-align: top;
                                            word-wrap: break-word;
                                          "
                                        >
                                          <table
                                            style="
                                              border-collapse: collapse;
                                              border-spacing: 0;
                                              padding-bottom: 0;
                                              padding-left: 0;
                                              padding-right: 0;
                                              padding-top: 0;
                                              text-align: left;
                                              vertical-align: top;
                                              width: 100%;
                                            "
                                          >
                                            <tr
                                              style="
                                                padding-bottom: 0;
                                                padding-left: 0;
                                                padding-right: 0;
                                                padding-top: 0;
                                                text-align: left;
                                                vertical-align: top;
                                              "
                                            >
                                              <td
                                                style="
                                                  -moz-hyphens: auto;
                                                  -webkit-hyphens: auto;
                                                  margin: 0;
                                                  border-collapse: collapse !important;
                                                  color: #7c7c7c;
                                                  font-family: Helvetica, Arial,
                                                    sans-serif;
                                                  font-size: 16px;
                                                  font-weight: 400;
                                                  hyphens: auto;
                                                  line-height: 1.3;
                                                  margin: 0;
                                                  padding-bottom: 0;
                                                  padding-left: 0;
                                                  padding-right: 0;
                                                  padding-top: 0;
                                                  text-align: left;
                                                  vertical-align: top;
                                                  width: 40%;
                                                  word-wrap: break-word;
                                                "
                                              >
                                                <table
                                                  class="spacer"
                                                  style="
                                                    border-collapse: collapse;
                                                    border-spacing: 0;
                                                    padding-bottom: 0;
                                                    padding-left: 0;
                                                    padding-right: 0;
                                                    padding-top: 0;
                                                    text-align: left;
                                                    vertical-align: top;
                                                    width: 100%;
                                                  "
                                                >
                                                  <tbody>
                                                    <tr
                                                      style="
                                                        padding-bottom: 0;
                                                        padding-left: 0;
                                                        padding-right: 0;
                                                        padding-top: 0;
                                                        text-align: left;
                                                        vertical-align: top;
                                                      "
                                                    >
                                                      <td
                                                        height="10"
                                                        style="
                                                          -moz-hyphens: auto;
                                                          -webkit-hyphens: auto;
                                                          margin: 0;
                                                          border-collapse: collapse !important;
                                                          color: #0a0a0a;
                                                          font-family: Helvetica,
                                                            Arial, sans-serif;
                                                          font-size: 10px;
                                                          font-weight: 400;
                                                          hyphens: auto;
                                                          line-height: 10px;
                                                          margin: 0;
                                                          mso-line-height-rule: exactly;
                                                          padding-bottom: 0;
                                                          padding-left: 0;
                                                          padding-right: 0;
                                                          padding-top: 0;
                                                          text-align: left;
                                                          vertical-align: top;
                                                          word-wrap: break-word;
                                                        "
                                                      >
                                                        &nbsp;
                                                      </td>
                                                    </tr>
                                                  </tbody>
                                                </table>
                                                Tipo de Inmueble:
                                                <table
                                                  class="spacer"
                                                  style="
                                                    border-collapse: collapse;
                                                    border-spacing: 0;
                                                    padding-bottom: 0;
                                                    padding-left: 0;
                                                    padding-right: 0;
                                                    padding-top: 0;
                                                    text-align: left;
                                                    vertical-align: top;
                                                    width: 100%;
                                                  "
                                                >
                                                  <tbody>
                                                    <tr
                                                      style="
                                                        padding-bottom: 0;
                                                        padding-left: 0;
                                                        padding-right: 0;
                                                        padding-top: 0;
                                                        text-align: left;
                                                        vertical-align: top;
                                                      "
                                                    >
                                                      <td
                                                        height="10"
                                                        style="
                                                          -moz-hyphens: auto;
                                                          -webkit-hyphens: auto;
                                                          margin: 0;
                                                          border-collapse: collapse !important;
                                                          color: #0a0a0a;
                                                          font-family: Helvetica,
                                                            Arial, sans-serif;
                                                          font-size: 10px;
                                                          font-weight: 400;
                                                          hyphens: auto;
                                                          line-height: 10px;
                                                          margin: 0;
                                                          mso-line-height-rule: exactly;
                                                          padding-bottom: 0;
                                                          padding-left: 0;
                                                          padding-right: 0;
                                                          padding-top: 0;
                                                          text-align: left;
                                                          vertical-align: top;
                                                          word-wrap: break-word;
                                                        "
                                                      >
                                                        &nbsp;
                                                      </td>
                                                    </tr>
                                                  </tbody>
                                                </table>
                                              </td>
                                              <td
                                                style="
                                                  -moz-hyphens: auto;
                                                  -webkit-hyphens: auto;
                                                  margin: 0;
                                                  border-collapse: collapse !important;
                                                  color: #0a0a0a;
                                                  font-family: Helvetica, Arial,
                                                    sans-serif;
                                                  font-size: 16px;
                                                  font-weight: 400;
                                                  hyphens: auto;
                                                  line-height: 1.3;
                                                  margin: 0;
                                                  padding-bottom: 0;
                                                  padding-left: 0;
                                                  padding-right: 0;
                                                  padding-top: 0;
                                                  text-align: left;
                                                  vertical-align: top;
                                                  word-wrap: break-word;
                                                "
                                              >
                                                <table
                                                  class="spacer"
                                                  style="
                                                    border-collapse: collapse;
                                                    border-spacing: 0;
                                                    padding-bottom: 0;
                                                    padding-left: 0;
                                                    padding-right: 0;
                                                    padding-top: 0;
                                                    text-align: left;
                                                    vertical-align: top;
                                                    width: 100%;
                                                  "
                                                >
                                                  <tbody>
                                                    <tr
                                                      style="
                                                        padding-bottom: 0;
                                                        padding-left: 0;
                                                        padding-right: 0;
                                                        padding-top: 0;
                                                        text-align: left;
                                                        vertical-align: top;
                                                      "
                                                    >
                                                      <td
                                                        height="10"
                                                        style="
                                                          -moz-hyphens: auto;
                                                          -webkit-hyphens: auto;
                                                          margin: 0;
                                                          border-collapse: collapse !important;
                                                          color: #0a0a0a;
                                                          font-family: Helvetica,
                                                            Arial, sans-serif;
                                                          font-size: 10px;
                                                          font-weight: 400;
                                                          hyphens: auto;
                                                          line-height: 10px;
                                                          margin: 0;
                                                          mso-line-height-rule: exactly;
                                                          padding-bottom: 0;
                                                          padding-left: 0;
                                                          padding-right: 0;
                                                          padding-top: 0;
                                                          text-align: left;
                                                          vertical-align: top;
                                                          word-wrap: break-word;
                                                        "
                                                      >
                                                        &nbsp;
                                                      </td>
                                                    </tr>
                                                  </tbody>
                                                </table>
                                                <strong
                                                  v-if="
                                                    page.data.lead
                                                      .project_type_department_rel
                                                  "
                                                  >Departamento
                                                  {{
                                                    page.data.lead
                                                      .project_type_department_rel
                                                      .name
                                                  }}</strong
                                                >
                                                <table
                                                  class="spacer"
                                                  style="
                                                    border-collapse: collapse;
                                                    border-spacing: 0;
                                                    padding-bottom: 0;
                                                    padding-left: 0;
                                                    padding-right: 0;
                                                    padding-top: 0;
                                                    text-align: left;
                                                    vertical-align: top;
                                                    width: 100%;
                                                  "
                                                >
                                                  <tbody>
                                                    <tr
                                                      style="
                                                        padding-bottom: 0;
                                                        padding-left: 0;
                                                        padding-right: 0;
                                                        padding-top: 0;
                                                        text-align: left;
                                                        vertical-align: top;
                                                      "
                                                    >
                                                      <td
                                                        height="10"
                                                        style="
                                                          -moz-hyphens: auto;
                                                          -webkit-hyphens: auto;
                                                          margin: 0;
                                                          border-collapse: collapse !important;
                                                          color: #0a0a0a;
                                                          font-family: Helvetica,
                                                            Arial, sans-serif;
                                                          font-size: 10px;
                                                          font-weight: 400;
                                                          hyphens: auto;
                                                          line-height: 10px;
                                                          margin: 0;
                                                          mso-line-height-rule: exactly;
                                                          padding-bottom: 0;
                                                          padding-left: 0;
                                                          padding-right: 0;
                                                          padding-top: 0;
                                                          text-align: left;
                                                          vertical-align: top;
                                                          word-wrap: break-word;
                                                        "
                                                      >
                                                        &nbsp;
                                                      </td>
                                                    </tr>
                                                  </tbody>
                                                </table>
                                              </td>
                                            </tr>
                                            <tr
                                              style="
                                                padding-bottom: 0;
                                                padding-left: 0;
                                                padding-right: 0;
                                                padding-top: 0;
                                                text-align: left;
                                                vertical-align: top;
                                              "
                                            >
                                              <td
                                                style="
                                                  -moz-hyphens: auto;
                                                  -webkit-hyphens: auto;
                                                  margin: 0;
                                                  border-collapse: collapse !important;
                                                  color: #7c7c7c;
                                                  font-family: Helvetica, Arial,
                                                    sans-serif;
                                                  font-size: 16px;
                                                  font-weight: 400;
                                                  hyphens: auto;
                                                  line-height: 1.3;
                                                  margin: 0;
                                                  padding-bottom: 0;
                                                  padding-left: 0;
                                                  padding-right: 0;
                                                  padding-top: 0;
                                                  text-align: left;
                                                  vertical-align: top;
                                                  width: 40%;
                                                  word-wrap: break-word;
                                                "
                                              >
                                                <table
                                                  class="spacer"
                                                  style="
                                                    border-collapse: collapse;
                                                    border-spacing: 0;
                                                    padding-bottom: 0;
                                                    padding-left: 0;
                                                    padding-right: 0;
                                                    padding-top: 0;
                                                    text-align: left;
                                                    vertical-align: top;
                                                    width: 100%;
                                                  "
                                                >
                                                  <tbody>
                                                    <tr
                                                      style="
                                                        padding-bottom: 0;
                                                        padding-left: 0;
                                                        padding-right: 0;
                                                        padding-top: 0;
                                                        text-align: left;
                                                        vertical-align: top;
                                                      "
                                                    >
                                                      <td
                                                        height="10"
                                                        style="
                                                          -moz-hyphens: auto;
                                                          -webkit-hyphens: auto;
                                                          margin: 0;
                                                          border-collapse: collapse !important;
                                                          color: #0a0a0a;
                                                          font-family: Helvetica,
                                                            Arial, sans-serif;
                                                          font-size: 10px;
                                                          font-weight: 400;
                                                          hyphens: auto;
                                                          line-height: 10px;
                                                          margin: 0;
                                                          mso-line-height-rule: exactly;
                                                          padding-bottom: 0;
                                                          padding-left: 0;
                                                          padding-right: 0;
                                                          padding-top: 0;
                                                          text-align: left;
                                                          vertical-align: top;
                                                          word-wrap: break-word;
                                                        "
                                                      >
                                                        &nbsp;
                                                      </td>
                                                    </tr>
                                                  </tbody>
                                                </table>
                                                Metraje desde:
                                                <table
                                                  class="spacer"
                                                  style="
                                                    border-collapse: collapse;
                                                    border-spacing: 0;
                                                    padding-bottom: 0;
                                                    padding-left: 0;
                                                    padding-right: 0;
                                                    padding-top: 0;
                                                    text-align: left;
                                                    vertical-align: top;
                                                    width: 100%;
                                                  "
                                                >
                                                  <tbody>
                                                    <tr
                                                      style="
                                                        padding-bottom: 0;
                                                        padding-left: 0;
                                                        padding-right: 0;
                                                        padding-top: 0;
                                                        text-align: left;
                                                        vertical-align: top;
                                                      "
                                                    >
                                                      <td
                                                        height="10"
                                                        style="
                                                          -moz-hyphens: auto;
                                                          -webkit-hyphens: auto;
                                                          margin: 0;
                                                          border-collapse: collapse !important;
                                                          color: #0a0a0a;
                                                          font-family: Helvetica,
                                                            Arial, sans-serif;
                                                          font-size: 10px;
                                                          font-weight: 400;
                                                          hyphens: auto;
                                                          line-height: 10px;
                                                          margin: 0;
                                                          mso-line-height-rule: exactly;
                                                          padding-bottom: 0;
                                                          padding-left: 0;
                                                          padding-right: 0;
                                                          padding-top: 0;
                                                          text-align: left;
                                                          vertical-align: top;
                                                          word-wrap: break-word;
                                                        "
                                                      >
                                                        &nbsp;
                                                      </td>
                                                    </tr>
                                                  </tbody>
                                                </table>
                                              </td>
                                              <td
                                                style="
                                                  -moz-hyphens: auto;
                                                  -webkit-hyphens: auto;
                                                  margin: 0;
                                                  border-collapse: collapse !important;
                                                  color: #0a0a0a;
                                                  font-family: Helvetica, Arial,
                                                    sans-serif;
                                                  font-size: 16px;
                                                  font-weight: 400;
                                                  hyphens: auto;
                                                  line-height: 1.3;
                                                  margin: 0;
                                                  padding-bottom: 0;
                                                  padding-left: 0;
                                                  padding-right: 0;
                                                  padding-top: 0;
                                                  text-align: left;
                                                  vertical-align: top;
                                                  word-wrap: break-word;
                                                "
                                              >
                                                <table
                                                  class="spacer"
                                                  style="
                                                    border-collapse: collapse;
                                                    border-spacing: 0;
                                                    padding-bottom: 0;
                                                    padding-left: 0;
                                                    padding-right: 0;
                                                    padding-top: 0;
                                                    text-align: left;
                                                    vertical-align: top;
                                                    width: 100%;
                                                  "
                                                >
                                                  <tbody>
                                                    <tr
                                                      style="
                                                        padding-bottom: 0;
                                                        padding-left: 0;
                                                        padding-right: 0;
                                                        padding-top: 0;
                                                        text-align: left;
                                                        vertical-align: top;
                                                      "
                                                    >
                                                      <td
                                                        height="10"
                                                        style="
                                                          -moz-hyphens: auto;
                                                          -webkit-hyphens: auto;
                                                          margin: 0;
                                                          border-collapse: collapse !important;
                                                          color: #0a0a0a;
                                                          font-family: Helvetica,
                                                            Arial, sans-serif;
                                                          font-size: 10px;
                                                          font-weight: 400;
                                                          hyphens: auto;
                                                          line-height: 10px;
                                                          margin: 0;
                                                          mso-line-height-rule: exactly;
                                                          padding-bottom: 0;
                                                          padding-left: 0;
                                                          padding-right: 0;
                                                          padding-top: 0;
                                                          text-align: left;
                                                          vertical-align: top;
                                                          word-wrap: break-word;
                                                        "
                                                      >
                                                        &nbsp;
                                                      </td>
                                                    </tr>
                                                  </tbody>
                                                </table>
                                                <strong
                                                  v-if="
                                                    page.data.lead
                                                      .project_type_department_rel
                                                  "
                                                  >{{
                                                    page.data.lead
                                                      .project_type_department_rel
                                                      .area
                                                  }}
                                                  m2</strong
                                                >
                                                <table
                                                  class="spacer"
                                                  style="
                                                    border-collapse: collapse;
                                                    border-spacing: 0;
                                                    padding-bottom: 0;
                                                    padding-left: 0;
                                                    padding-right: 0;
                                                    padding-top: 0;
                                                    text-align: left;
                                                    vertical-align: top;
                                                    width: 100%;
                                                  "
                                                >
                                                  <tbody>
                                                    <tr
                                                      style="
                                                        padding-bottom: 0;
                                                        padding-left: 0;
                                                        padding-right: 0;
                                                        padding-top: 0;
                                                        text-align: left;
                                                        vertical-align: top;
                                                      "
                                                    >
                                                      <td
                                                        height="10"
                                                        style="
                                                          -moz-hyphens: auto;
                                                          -webkit-hyphens: auto;
                                                          margin: 0;
                                                          border-collapse: collapse !important;
                                                          color: #0a0a0a;
                                                          font-family: Helvetica,
                                                            Arial, sans-serif;
                                                          font-size: 10px;
                                                          font-weight: 400;
                                                          hyphens: auto;
                                                          line-height: 10px;
                                                          margin: 0;
                                                          mso-line-height-rule: exactly;
                                                          padding-bottom: 0;
                                                          padding-left: 0;
                                                          padding-right: 0;
                                                          padding-top: 0;
                                                          text-align: left;
                                                          vertical-align: top;
                                                          word-wrap: break-word;
                                                        "
                                                      >
                                                        &nbsp;
                                                      </td>
                                                    </tr>
                                                  </tbody>
                                                </table>
                                              </td>
                                            </tr>
                                            <tr
                                              style="
                                                padding-bottom: 0;
                                                padding-left: 0;
                                                padding-right: 0;
                                                padding-top: 0;
                                                text-align: left;
                                                vertical-align: top;
                                              "
                                            >
                                              <td
                                                style="
                                                  -moz-hyphens: auto;
                                                  -webkit-hyphens: auto;
                                                  margin: 0;
                                                  border-collapse: collapse !important;
                                                  color: #7c7c7c;
                                                  font-family: Helvetica, Arial,
                                                    sans-serif;
                                                  font-size: 16px;
                                                  font-weight: 400;
                                                  hyphens: auto;
                                                  line-height: 1.3;
                                                  margin: 0;
                                                  padding-bottom: 0;
                                                  padding-left: 0;
                                                  padding-right: 0;
                                                  padding-top: 0;
                                                  text-align: left;
                                                  vertical-align: top;
                                                  width: 40%;
                                                  word-wrap: break-word;
                                                "
                                              >
                                                <table
                                                  class="spacer"
                                                  style="
                                                    border-collapse: collapse;
                                                    border-spacing: 0;
                                                    padding-bottom: 0;
                                                    padding-left: 0;
                                                    padding-right: 0;
                                                    padding-top: 0;
                                                    text-align: left;
                                                    vertical-align: top;
                                                    width: 100%;
                                                  "
                                                >
                                                  <tbody>
                                                    <tr
                                                      style="
                                                        padding-bottom: 0;
                                                        padding-left: 0;
                                                        padding-right: 0;
                                                        padding-top: 0;
                                                        text-align: left;
                                                        vertical-align: top;
                                                      "
                                                    >
                                                      <td
                                                        height="10"
                                                        style="
                                                          -moz-hyphens: auto;
                                                          -webkit-hyphens: auto;
                                                          margin: 0;
                                                          border-collapse: collapse !important;
                                                          color: #0a0a0a;
                                                          font-family: Helvetica,
                                                            Arial, sans-serif;
                                                          font-size: 10px;
                                                          font-weight: 400;
                                                          hyphens: auto;
                                                          line-height: 10px;
                                                          margin: 0;
                                                          mso-line-height-rule: exactly;
                                                          padding-bottom: 0;
                                                          padding-left: 0;
                                                          padding-right: 0;
                                                          padding-top: 0;
                                                          text-align: left;
                                                          vertical-align: top;
                                                          word-wrap: break-word;
                                                        "
                                                      >
                                                        &nbsp;
                                                      </td>
                                                    </tr>
                                                  </tbody>
                                                </table>
                                                N° de Dormitorios:
                                                <table
                                                  class="spacer"
                                                  style="
                                                    border-collapse: collapse;
                                                    border-spacing: 0;
                                                    padding-bottom: 0;
                                                    padding-left: 0;
                                                    padding-right: 0;
                                                    padding-top: 0;
                                                    text-align: left;
                                                    vertical-align: top;
                                                    width: 100%;
                                                  "
                                                >
                                                  <tbody>
                                                    <tr
                                                      style="
                                                        padding-bottom: 0;
                                                        padding-left: 0;
                                                        padding-right: 0;
                                                        padding-top: 0;
                                                        text-align: left;
                                                        vertical-align: top;
                                                      "
                                                    >
                                                      <td
                                                        height="10"
                                                        style="
                                                          -moz-hyphens: auto;
                                                          -webkit-hyphens: auto;
                                                          margin: 0;
                                                          border-collapse: collapse !important;
                                                          color: #0a0a0a;
                                                          font-family: Helvetica,
                                                            Arial, sans-serif;
                                                          font-size: 10px;
                                                          font-weight: 400;
                                                          hyphens: auto;
                                                          line-height: 10px;
                                                          margin: 0;
                                                          mso-line-height-rule: exactly;
                                                          padding-bottom: 0;
                                                          padding-left: 0;
                                                          padding-right: 0;
                                                          padding-top: 0;
                                                          text-align: left;
                                                          vertical-align: top;
                                                          word-wrap: break-word;
                                                        "
                                                      >
                                                        &nbsp;
                                                      </td>
                                                    </tr>
                                                  </tbody>
                                                </table>
                                              </td>
                                              <td
                                                style="
                                                  -moz-hyphens: auto;
                                                  -webkit-hyphens: auto;
                                                  margin: 0;
                                                  border-collapse: collapse !important;
                                                  color: #0a0a0a;
                                                  font-family: Helvetica, Arial,
                                                    sans-serif;
                                                  font-size: 16px;
                                                  font-weight: 400;
                                                  hyphens: auto;
                                                  line-height: 1.3;
                                                  margin: 0;
                                                  padding-bottom: 0;
                                                  padding-left: 0;
                                                  padding-right: 0;
                                                  padding-top: 0;
                                                  text-align: left;
                                                  vertical-align: top;
                                                  word-wrap: break-word;
                                                "
                                              >
                                                <table
                                                  class="spacer"
                                                  style="
                                                    border-collapse: collapse;
                                                    border-spacing: 0;
                                                    padding-bottom: 0;
                                                    padding-left: 0;
                                                    padding-right: 0;
                                                    padding-top: 0;
                                                    text-align: left;
                                                    vertical-align: top;
                                                    width: 100%;
                                                  "
                                                >
                                                  <tbody>
                                                    <tr
                                                      style="
                                                        padding-bottom: 0;
                                                        padding-left: 0;
                                                        padding-right: 0;
                                                        padding-top: 0;
                                                        text-align: left;
                                                        vertical-align: top;
                                                      "
                                                    >
                                                      <td
                                                        height="10"
                                                        style="
                                                          -moz-hyphens: auto;
                                                          -webkit-hyphens: auto;
                                                          margin: 0;
                                                          border-collapse: collapse !important;
                                                          color: #0a0a0a;
                                                          font-family: Helvetica,
                                                            Arial, sans-serif;
                                                          font-size: 10px;
                                                          font-weight: 400;
                                                          hyphens: auto;
                                                          line-height: 10px;
                                                          margin: 0;
                                                          mso-line-height-rule: exactly;
                                                          padding-bottom: 0;
                                                          padding-left: 0;
                                                          padding-right: 0;
                                                          padding-top: 0;
                                                          text-align: left;
                                                          vertical-align: top;
                                                          word-wrap: break-word;
                                                        "
                                                      >
                                                        &nbsp;
                                                      </td>
                                                    </tr>
                                                  </tbody>
                                                </table>
                                                <strong>{{
                                                  page.data.lead
                                                    .project_type_department_rel
                                                    .room
                                                }}</strong>
                                                <table
                                                  class="spacer"
                                                  style="
                                                    border-collapse: collapse;
                                                    border-spacing: 0;
                                                    padding-bottom: 0;
                                                    padding-left: 0;
                                                    padding-right: 0;
                                                    padding-top: 0;
                                                    text-align: left;
                                                    vertical-align: top;
                                                    width: 100%;
                                                  "
                                                >
                                                  <tbody>
                                                    <tr
                                                      style="
                                                        padding-bottom: 0;
                                                        padding-left: 0;
                                                        padding-right: 0;
                                                        padding-top: 0;
                                                        text-align: left;
                                                        vertical-align: top;
                                                      "
                                                    >
                                                      <td
                                                        height="10"
                                                        style="
                                                          -moz-hyphens: auto;
                                                          -webkit-hyphens: auto;
                                                          margin: 0;
                                                          border-collapse: collapse !important;
                                                          color: #0a0a0a;
                                                          font-family: Helvetica,
                                                            Arial, sans-serif;
                                                          font-size: 10px;
                                                          font-weight: 400;
                                                          hyphens: auto;
                                                          line-height: 10px;
                                                          margin: 0;
                                                          mso-line-height-rule: exactly;
                                                          padding-bottom: 0;
                                                          padding-left: 0;
                                                          padding-right: 0;
                                                          padding-top: 0;
                                                          text-align: left;
                                                          vertical-align: top;
                                                          word-wrap: break-word;
                                                        "
                                                      >
                                                        &nbsp;
                                                      </td>
                                                    </tr>
                                                  </tbody>
                                                </table>
                                              </td>
                                            </tr>
                                            <tr
                                              style="
                                                padding-bottom: 0;
                                                padding-left: 0;
                                                padding-right: 0;
                                                padding-top: 0;
                                                text-align: left;
                                                vertical-align: top;
                                              "
                                            >
                                              <td
                                                style="
                                                  -moz-hyphens: auto;
                                                  -webkit-hyphens: auto;
                                                  margin: 0;
                                                  border-collapse: collapse !important;
                                                  color: #7c7c7c;
                                                  font-family: Helvetica, Arial,
                                                    sans-serif;
                                                  font-size: 16px;
                                                  font-weight: 400;
                                                  hyphens: auto;
                                                  line-height: 1.3;
                                                  margin: 0;
                                                  padding-bottom: 0;
                                                  padding-left: 0;
                                                  padding-right: 0;
                                                  padding-top: 0;
                                                  text-align: left;
                                                  vertical-align: top;
                                                  width: 40%;
                                                  word-wrap: break-word;
                                                "
                                              >
                                                <table
                                                  class="spacer"
                                                  style="
                                                    border-collapse: collapse;
                                                    border-spacing: 0;
                                                    padding-bottom: 0;
                                                    padding-left: 0;
                                                    padding-right: 0;
                                                    padding-top: 0;
                                                    text-align: left;
                                                    vertical-align: top;
                                                    width: 100%;
                                                  "
                                                >
                                                  <tbody>
                                                    <tr
                                                      style="
                                                        padding-bottom: 0;
                                                        padding-left: 0;
                                                        padding-right: 0;
                                                        padding-top: 0;
                                                        text-align: left;
                                                        vertical-align: top;
                                                      "
                                                    >
                                                      <td
                                                        height="10"
                                                        style="
                                                          -moz-hyphens: auto;
                                                          -webkit-hyphens: auto;
                                                          margin: 0;
                                                          border-collapse: collapse !important;
                                                          color: #0a0a0a;
                                                          font-family: Helvetica,
                                                            Arial, sans-serif;
                                                          font-size: 10px;
                                                          font-weight: 400;
                                                          hyphens: auto;
                                                          line-height: 10px;
                                                          margin: 0;
                                                          mso-line-height-rule: exactly;
                                                          padding-bottom: 0;
                                                          padding-left: 0;
                                                          padding-right: 0;
                                                          padding-top: 0;
                                                          text-align: left;
                                                          vertical-align: top;
                                                          word-wrap: break-word;
                                                        "
                                                      >
                                                        &nbsp;
                                                      </td>
                                                    </tr>
                                                  </tbody>
                                                </table>
                                                Precio dpto. desde:
                                                <template
                                                  v-if="
                                                    page.data.lead.project_rel
                                                      .commentary_quotation
                                                  "
                                                  >*</template
                                                >
                                                <table
                                                  class="spacer"
                                                  style="
                                                    border-collapse: collapse;
                                                    border-spacing: 0;
                                                    padding-bottom: 0;
                                                    padding-left: 0;
                                                    padding-right: 0;
                                                    padding-top: 0;
                                                    text-align: left;
                                                    vertical-align: top;
                                                    width: 100%;
                                                  "
                                                >
                                                  <tbody>
                                                    <tr
                                                      style="
                                                        padding-bottom: 0;
                                                        padding-left: 0;
                                                        padding-right: 0;
                                                        padding-top: 0;
                                                        text-align: left;
                                                        vertical-align: top;
                                                      "
                                                    >
                                                      <td
                                                        height="10"
                                                        style="
                                                          -moz-hyphens: auto;
                                                          -webkit-hyphens: auto;
                                                          margin: 0;
                                                          border-collapse: collapse !important;
                                                          color: #0a0a0a;
                                                          font-family: Helvetica,
                                                            Arial, sans-serif;
                                                          font-size: 10px;
                                                          font-weight: 400;
                                                          hyphens: auto;
                                                          line-height: 10px;
                                                          margin: 0;
                                                          mso-line-height-rule: exactly;
                                                          padding-bottom: 0;
                                                          padding-left: 0;
                                                          padding-right: 0;
                                                          padding-top: 0;
                                                          text-align: left;
                                                          vertical-align: top;
                                                          word-wrap: break-word;
                                                        "
                                                      >
                                                        &nbsp;
                                                      </td>
                                                    </tr>
                                                  </tbody>
                                                </table>
                                              </td>
                                              <td
                                                style="
                                                  -moz-hyphens: auto;
                                                  -webkit-hyphens: auto;
                                                  margin: 0;
                                                  border-collapse: collapse !important;
                                                  color: #0a0a0a;
                                                  font-family: Helvetica, Arial,
                                                    sans-serif;
                                                  font-size: 16px;
                                                  font-weight: 400;
                                                  hyphens: auto;
                                                  line-height: 1.3;
                                                  margin: 0;
                                                  padding-bottom: 0;
                                                  padding-left: 0;
                                                  padding-right: 0;
                                                  padding-top: 0;
                                                  text-align: left;
                                                  vertical-align: top;
                                                  word-wrap: break-word;
                                                "
                                              >
                                                <table
                                                  class="spacer"
                                                  style="
                                                    border-collapse: collapse;
                                                    border-spacing: 0;
                                                    padding-bottom: 0;
                                                    padding-left: 0;
                                                    padding-right: 0;
                                                    padding-top: 0;
                                                    text-align: left;
                                                    vertical-align: top;
                                                    width: 100%;
                                                  "
                                                >
                                                  <tbody>
                                                    <tr
                                                      style="
                                                        padding-bottom: 0;
                                                        padding-left: 0;
                                                        padding-right: 0;
                                                        padding-top: 0;
                                                        text-align: left;
                                                        vertical-align: top;
                                                      "
                                                    >
                                                      <td
                                                        height="10"
                                                        style="
                                                          -moz-hyphens: auto;
                                                          -webkit-hyphens: auto;
                                                          margin: 0;
                                                          border-collapse: collapse !important;
                                                          color: #0a0a0a;
                                                          font-family: Helvetica,
                                                            Arial, sans-serif;
                                                          font-size: 10px;
                                                          font-weight: 400;
                                                          hyphens: auto;
                                                          line-height: 10px;
                                                          margin: 0;
                                                          mso-line-height-rule: exactly;
                                                          padding-bottom: 0;
                                                          padding-left: 0;
                                                          padding-right: 0;
                                                          padding-top: 0;
                                                          text-align: left;
                                                          vertical-align: top;
                                                          word-wrap: break-word;
                                                        "
                                                      >
                                                        &nbsp;
                                                      </td>
                                                    </tr>
                                                  </tbody>
                                                </table>
                                                <strong>{{
                                                  page.data.lead
                                                    .project_type_department_rel
                                                    .price_format
                                                }}</strong>
                                                <table
                                                  class="spacer"
                                                  style="
                                                    border-collapse: collapse;
                                                    border-spacing: 0;
                                                    padding-bottom: 0;
                                                    padding-left: 0;
                                                    padding-right: 0;
                                                    padding-top: 0;
                                                    text-align: left;
                                                    vertical-align: top;
                                                    width: 100%;
                                                  "
                                                >
                                                  <tbody>
                                                    <tr
                                                      style="
                                                        padding-bottom: 0;
                                                        padding-left: 0;
                                                        padding-right: 0;
                                                        padding-top: 0;
                                                        text-align: left;
                                                        vertical-align: top;
                                                      "
                                                    >
                                                      <td
                                                        height="10"
                                                        style="
                                                          -moz-hyphens: auto;
                                                          -webkit-hyphens: auto;
                                                          margin: 0;
                                                          border-collapse: collapse !important;
                                                          color: #0a0a0a;
                                                          font-family: Helvetica,
                                                            Arial, sans-serif;
                                                          font-size: 10px;
                                                          font-weight: 400;
                                                          hyphens: auto;
                                                          line-height: 10px;
                                                          margin: 0;
                                                          mso-line-height-rule: exactly;
                                                          padding-bottom: 0;
                                                          padding-left: 0;
                                                          padding-right: 0;
                                                          padding-top: 0;
                                                          text-align: left;
                                                          vertical-align: top;
                                                          word-wrap: break-word;
                                                        "
                                                      >
                                                        &nbsp;
                                                      </td>
                                                    </tr>
                                                  </tbody>
                                                </table>
                                              </td>
                                            </tr>
                                            <tr
                                              v-if="
                                                page.data.lead.project_rel
                                                  .price_parking
                                              "
                                              style="
                                                padding-bottom: 0;
                                                padding-left: 0;
                                                padding-right: 0;
                                                padding-top: 0;
                                                text-align: left;
                                                vertical-align: top;
                                              "
                                            >
                                              <td
                                                style="
                                                  -moz-hyphens: auto;
                                                  -webkit-hyphens: auto;
                                                  margin: 0;
                                                  border-collapse: collapse !important;
                                                  color: #7c7c7c;
                                                  font-family: Helvetica, Arial,
                                                    sans-serif;
                                                  font-size: 16px;
                                                  font-weight: 400;
                                                  hyphens: auto;
                                                  line-height: 1.3;
                                                  margin: 0;
                                                  padding-bottom: 0;
                                                  padding-left: 0;
                                                  padding-right: 0;
                                                  padding-top: 0;
                                                  text-align: left;
                                                  vertical-align: top;
                                                  width: 40%;
                                                  word-wrap: break-word;
                                                "
                                              >
                                                <table
                                                  class="spacer"
                                                  style="
                                                    border-collapse: collapse;
                                                    border-spacing: 0;
                                                    padding-bottom: 0;
                                                    padding-left: 0;
                                                    padding-right: 0;
                                                    padding-top: 0;
                                                    text-align: left;
                                                    vertical-align: top;
                                                    width: 100%;
                                                  "
                                                >
                                                  <tbody>
                                                    <tr
                                                      style="
                                                        padding-bottom: 0;
                                                        padding-left: 0;
                                                        padding-right: 0;
                                                        padding-top: 0;
                                                        text-align: left;
                                                        vertical-align: top;
                                                      "
                                                    >
                                                      <td
                                                        height="10"
                                                        style="
                                                          -moz-hyphens: auto;
                                                          -webkit-hyphens: auto;
                                                          margin: 0;
                                                          border-collapse: collapse !important;
                                                          color: #0a0a0a;
                                                          font-family: Helvetica,
                                                            Arial, sans-serif;
                                                          font-size: 10px;
                                                          font-weight: 400;
                                                          hyphens: auto;
                                                          line-height: 10px;
                                                          margin: 0;
                                                          mso-line-height-rule: exactly;
                                                          padding-bottom: 0;
                                                          padding-left: 0;
                                                          padding-right: 0;
                                                          padding-top: 0;
                                                          text-align: left;
                                                          vertical-align: top;
                                                          word-wrap: break-word;
                                                        "
                                                      >
                                                        &nbsp;
                                                      </td>
                                                    </tr>
                                                  </tbody>
                                                </table>
                                                Precio Estacionamiento:
                                                <table
                                                  class="spacer"
                                                  style="
                                                    border-collapse: collapse;
                                                    border-spacing: 0;
                                                    padding-bottom: 0;
                                                    padding-left: 0;
                                                    padding-right: 0;
                                                    padding-top: 0;
                                                    text-align: left;
                                                    vertical-align: top;
                                                    width: 100%;
                                                  "
                                                >
                                                  <tbody>
                                                    <tr
                                                      style="
                                                        padding-bottom: 0;
                                                        padding-left: 0;
                                                        padding-right: 0;
                                                        padding-top: 0;
                                                        text-align: left;
                                                        vertical-align: top;
                                                      "
                                                    >
                                                      <td
                                                        height="10"
                                                        style="
                                                          -moz-hyphens: auto;
                                                          -webkit-hyphens: auto;
                                                          margin: 0;
                                                          border-collapse: collapse !important;
                                                          color: #0a0a0a;
                                                          font-family: Helvetica,
                                                            Arial, sans-serif;
                                                          font-size: 10px;
                                                          font-weight: 400;
                                                          hyphens: auto;
                                                          line-height: 10px;
                                                          margin: 0;
                                                          mso-line-height-rule: exactly;
                                                          padding-bottom: 0;
                                                          padding-left: 0;
                                                          padding-right: 0;
                                                          padding-top: 0;
                                                          text-align: left;
                                                          vertical-align: top;
                                                          word-wrap: break-word;
                                                        "
                                                      >
                                                        &nbsp;
                                                      </td>
                                                    </tr>
                                                  </tbody>
                                                </table>
                                              </td>
                                              <td
                                                style="
                                                  -moz-hyphens: auto;
                                                  -webkit-hyphens: auto;
                                                  margin: 0;
                                                  border-collapse: collapse !important;
                                                  color: #0a0a0a;
                                                  font-family: Helvetica, Arial,
                                                    sans-serif;
                                                  font-size: 16px;
                                                  font-weight: 400;
                                                  hyphens: auto;
                                                  line-height: 1.3;
                                                  margin: 0;
                                                  padding-bottom: 0;
                                                  padding-left: 0;
                                                  padding-right: 0;
                                                  padding-top: 0;
                                                  text-align: left;
                                                  vertical-align: top;
                                                  word-wrap: break-word;
                                                "
                                              >
                                                <table
                                                  class="spacer"
                                                  style="
                                                    border-collapse: collapse;
                                                    border-spacing: 0;
                                                    padding-bottom: 0;
                                                    padding-left: 0;
                                                    padding-right: 0;
                                                    padding-top: 0;
                                                    text-align: left;
                                                    vertical-align: top;
                                                    width: 100%;
                                                  "
                                                >
                                                  <tbody>
                                                    <tr
                                                      style="
                                                        padding-bottom: 0;
                                                        padding-left: 0;
                                                        padding-right: 0;
                                                        padding-top: 0;
                                                        text-align: left;
                                                        vertical-align: top;
                                                      "
                                                    >
                                                      <td
                                                        height="10"
                                                        style="
                                                          -moz-hyphens: auto;
                                                          -webkit-hyphens: auto;
                                                          margin: 0;
                                                          border-collapse: collapse !important;
                                                          color: #0a0a0a;
                                                          font-family: Helvetica,
                                                            Arial, sans-serif;
                                                          font-size: 10px;
                                                          font-weight: 400;
                                                          hyphens: auto;
                                                          line-height: 10px;
                                                          margin: 0;
                                                          mso-line-height-rule: exactly;
                                                          padding-bottom: 0;
                                                          padding-left: 0;
                                                          padding-right: 0;
                                                          padding-top: 0;
                                                          text-align: left;
                                                          vertical-align: top;
                                                          word-wrap: break-word;
                                                        "
                                                      >
                                                        &nbsp;
                                                      </td>
                                                    </tr>
                                                  </tbody>
                                                </table>
                                                <pre
                                                  v-html="
                                                    page.data.lead.project_rel
                                                      .price_parking
                                                  "
                                                ></pre>
                                                <table
                                                  class="spacer"
                                                  style="
                                                    border-collapse: collapse;
                                                    border-spacing: 0;
                                                    padding-bottom: 0;
                                                    padding-left: 0;
                                                    padding-right: 0;
                                                    padding-top: 0;
                                                    text-align: left;
                                                    vertical-align: top;
                                                    width: 100%;
                                                  "
                                                >
                                                  <tbody>
                                                    <tr
                                                      style="
                                                        padding-bottom: 0;
                                                        padding-left: 0;
                                                        padding-right: 0;
                                                        padding-top: 0;
                                                        text-align: left;
                                                        vertical-align: top;
                                                      "
                                                    >
                                                      <td
                                                        height="10"
                                                        style="
                                                          -moz-hyphens: auto;
                                                          -webkit-hyphens: auto;
                                                          margin: 0;
                                                          border-collapse: collapse !important;
                                                          color: #0a0a0a;
                                                          font-family: Helvetica,
                                                            Arial, sans-serif;
                                                          font-size: 10px;
                                                          font-weight: 400;
                                                          hyphens: auto;
                                                          line-height: 10px;
                                                          margin: 0;
                                                          mso-line-height-rule: exactly;
                                                          padding-bottom: 0;
                                                          padding-left: 0;
                                                          padding-right: 0;
                                                          padding-top: 0;
                                                          text-align: left;
                                                          vertical-align: top;
                                                          word-wrap: break-word;
                                                        "
                                                      >
                                                        &nbsp;
                                                      </td>
                                                    </tr>
                                                  </tbody>
                                                </table>
                                              </td>
                                            </tr>
                                            <tr
                                              v-if="
                                                page.data.lead.project_rel
                                                  .commentary_quotation
                                              "
                                              style="
                                                padding-bottom: 0;
                                                padding-left: 0;
                                                padding-right: 0;
                                                padding-top: 0;
                                                text-align: left;
                                                vertical-align: top;
                                              "
                                            >
                                              <td
                                                colspan="2"
                                                style="
                                                  -moz-hyphens: auto;
                                                  -webkit-hyphens: auto;
                                                  margin: 0;
                                                  border-collapse: collapse !important;
                                                  color: #0a0a0a;
                                                  font-family: Helvetica, Arial,
                                                    sans-serif;
                                                  font-size: 16px;
                                                  font-weight: 400;
                                                  hyphens: auto;
                                                  line-height: 1.3;
                                                  margin: 0;
                                                  padding-bottom: 0;
                                                  padding-left: 0;
                                                  padding-right: 0;
                                                  padding-top: 0;
                                                  text-align: left;
                                                  vertical-align: top;
                                                  word-wrap: break-word;
                                                "
                                              >
                                                <table
                                                  class="spacer"
                                                  style="
                                                    border-collapse: collapse;
                                                    border-spacing: 0;
                                                    padding-bottom: 0;
                                                    padding-left: 0;
                                                    padding-right: 0;
                                                    padding-top: 0;
                                                    text-align: left;
                                                    vertical-align: top;
                                                    width: 100%;
                                                  "
                                                >
                                                  <tbody>
                                                    <tr
                                                      style="
                                                        padding-bottom: 0;
                                                        padding-left: 0;
                                                        padding-right: 0;
                                                        padding-top: 0;
                                                        text-align: left;
                                                        vertical-align: top;
                                                      "
                                                    >
                                                      <td
                                                        height="10"
                                                        style="
                                                          -moz-hyphens: auto;
                                                          -webkit-hyphens: auto;
                                                          margin: 0;
                                                          border-collapse: collapse !important;
                                                          color: #0a0a0a;
                                                          font-family: Helvetica,
                                                            Arial, sans-serif;
                                                          font-size: 10px;
                                                          font-weight: 400;
                                                          hyphens: auto;
                                                          line-height: 10px;
                                                          margin: 0;
                                                          mso-line-height-rule: exactly;
                                                          padding-bottom: 0;
                                                          padding-left: 0;
                                                          padding-right: 0;
                                                          padding-top: 0;
                                                          text-align: left;
                                                          vertical-align: top;
                                                          word-wrap: break-word;
                                                        "
                                                      >
                                                        &nbsp;
                                                      </td>
                                                    </tr>
                                                  </tbody>
                                                </table>
                                                <i
                                                  style="
                                                    font-size: 14px;
                                                    color: #7c7c7c;
                                                  "
                                                  >(*)
                                                  {{
                                                    page.data.lead.project_rel
                                                      .commentary_quotation
                                                  }}</i
                                                >
                                              </td>
                                            </tr>
                                          </table>
                                        </th>
                                        <th
                                          class="expander"
                                          style="
                                            -moz-hyphens: auto;
                                            -webkit-hyphens: auto;
                                            margin: 0;
                                            border-collapse: collapse !important;
                                            color: #0a0a0a;
                                            font-family: Helvetica, Arial,
                                              sans-serif;
                                            font-size: 16px;
                                            font-weight: 400;
                                            hyphens: auto;
                                            line-height: 1.3;
                                            margin: 0;
                                            padding: 0 !important;
                                            padding-bottom: 0;
                                            padding-left: 0;
                                            padding-right: 0;
                                            padding-top: 0;
                                            text-align: left;
                                            vertical-align: top;
                                            visibility: hidden;
                                            width: 0;
                                            word-wrap: break-word;
                                          "
                                        ></th>
                                      </tr>
                                    </tbody>
                                  </table>
                                </th>
                              </tr>
                            </tbody>
                          </table>
                          <table
                            class="spacer"
                            style="
                              border-collapse: collapse;
                              border-spacing: 0;
                              padding-bottom: 0;
                              padding-left: 0;
                              padding-right: 0;
                              padding-top: 0;
                              text-align: left;
                              vertical-align: top;
                              width: 100%;
                            "
                          >
                            <tbody>
                              <tr
                                style="
                                  padding-bottom: 0;
                                  padding-left: 0;
                                  padding-right: 0;
                                  padding-top: 0;
                                  text-align: left;
                                  vertical-align: top;
                                "
                              >
                                <td
                                  height="16"
                                  style="
                                    -moz-hyphens: auto;
                                    -webkit-hyphens: auto;
                                    margin: 0;
                                    border-collapse: collapse !important;
                                    color: #0a0a0a;
                                    font-family: Helvetica, Arial, sans-serif;
                                    font-size: 16px;
                                    font-weight: 400;
                                    hyphens: auto;
                                    line-height: 16px;
                                    margin: 0;
                                    mso-line-height-rule: exactly;
                                    padding-bottom: 0;
                                    padding-left: 0;
                                    padding-right: 0;
                                    padding-top: 0;
                                    text-align: left;
                                    vertical-align: top;
                                    word-wrap: break-word;
                                  "
                                >
                                  &nbsp;
                                </td>
                              </tr>
                            </tbody>
                          </table>
                          <table
                            class="row"
                            style="
                              max-width: 600px;
                              border-collapse: collapse;
                              border-spacing: 0;
                              display: table;
                              padding: 0;
                              padding-bottom: 0;
                              padding-left: 0;
                              padding-right: 0;
                              padding-top: 0;
                              position: relative;
                              text-align: left;
                              vertical-align: top;
                              width: 100%;
                            "
                          >
                            <tbody>
                              <tr
                                style="
                                  padding-bottom: 0;
                                  padding-left: 0;
                                  padding-right: 0;
                                  padding-top: 0;
                                  text-align: left;
                                  vertical-align: top;
                                "
                              >
                                <th
                                  class="small-12 large-12 columns first last"
                                  style="
                                    -moz-hyphens: auto;
                                    -webkit-hyphens: auto;
                                    margin: 0 auto;
                                    border-collapse: collapse !important;
                                    color: #0a0a0a;
                                    font-family: Helvetica, Arial, sans-serif;
                                    font-size: 16px;
                                    font-weight: 400;
                                    hyphens: auto;
                                    line-height: 1.3;
                                    margin: 0 auto;
                                    padding-bottom: 0;
                                    padding-left: 30px;
                                    padding-right: 30px;
                                    padding-top: 0;
                                    text-align: left;
                                    vertical-align: top;
                                    width: 550px;
                                    word-wrap: break-word;
                                  "
                                >
                                  <table
                                    style="
                                      border-collapse: collapse;
                                      border-spacing: 0;
                                      padding-bottom: 0;
                                      padding-left: 0;
                                      padding-right: 0;
                                      padding-top: 0;
                                      text-align: left;
                                      vertical-align: top;
                                      width: 100%;
                                    "
                                  >
                                    <tbody>
                                      <tr
                                        style="
                                          padding-bottom: 0;
                                          padding-left: 0;
                                          padding-right: 0;
                                          padding-top: 0;
                                          text-align: left;
                                          vertical-align: top;
                                        "
                                      >
                                        <th
                                          style="
                                            -moz-hyphens: auto;
                                            -webkit-hyphens: auto;
                                            margin: 0;
                                            border-collapse: collapse !important;
                                            color: #0a0a0a;
                                            font-family: Helvetica, Arial,
                                              sans-serif;
                                            font-size: 16px;
                                            font-weight: 400;
                                            hyphens: auto;
                                            line-height: 1.3;
                                            margin: 0;
                                            padding-bottom: 0;
                                            padding-left: 0;
                                            padding-right: 0;
                                            padding-top: 0;
                                            text-align: left;
                                            vertical-align: top;
                                            word-wrap: break-word;
                                          "
                                        >
                                          <!--<center
                                            style="min-width: 490px; width: 100%"
                                          >-->
                                          <center style="width: 100%">
                                            <h5
                                              class="text-primary text-center float-center"
                                              style="
                                                margin: 0;
                                                margin-bottom: 10px;
                                                color: #0b6fa6;
                                                font-family: Helvetica, Arial,
                                                  sans-serif;
                                                font-size: 20px;
                                                font-weight: 400;
                                                line-height: 1.3;
                                                margin: 0;
                                                margin-bottom: 0;
                                                padding-bottom: 0;
                                                padding-left: 0;
                                                padding-right: 0;
                                                padding-top: 0;
                                                text-align: center;
                                                word-wrap: normal;
                                              "
                                              align="center"
                                            >
                                              <strong
                                                >Departamento
                                                {{
                                                  page.data.lead
                                                    .project_type_department_rel
                                                    .name
                                                }}</strong
                                              >
                                            </h5>
                                          </center>
                                        </th>
                                        <th
                                          class="expander"
                                          style="
                                            -moz-hyphens: auto;
                                            -webkit-hyphens: auto;
                                            margin: 0;
                                            border-collapse: collapse !important;
                                            color: #0a0a0a;
                                            font-family: Helvetica, Arial,
                                              sans-serif;
                                            font-size: 16px;
                                            font-weight: 400;
                                            hyphens: auto;
                                            line-height: 1.3;
                                            margin: 0;
                                            padding: 0 !important;
                                            padding-bottom: 0;
                                            padding-left: 0;
                                            padding-right: 0;
                                            padding-top: 0;
                                            text-align: left;
                                            vertical-align: top;
                                            visibility: hidden;
                                            width: 0;
                                            word-wrap: break-word;
                                          "
                                        ></th>
                                      </tr>
                                    </tbody>
                                  </table>
                                </th>
                              </tr>
                            </tbody>
                          </table>
                          <table
                            class="spacer"
                            style="
                              border-collapse: collapse;
                              border-spacing: 0;
                              padding-bottom: 0;
                              padding-left: 0;
                              padding-right: 0;
                              padding-top: 0;
                              text-align: left;
                              vertical-align: top;
                              width: 100%;
                            "
                          >
                            <tbody>
                              <tr
                                style="
                                  padding-bottom: 0;
                                  padding-left: 0;
                                  padding-right: 0;
                                  padding-top: 0;
                                  text-align: left;
                                  vertical-align: top;
                                "
                              >
                                <td
                                  height="16"
                                  style="
                                    -moz-hyphens: auto;
                                    -webkit-hyphens: auto;
                                    margin: 0;
                                    border-collapse: collapse !important;
                                    color: #0a0a0a;
                                    font-family: Helvetica, Arial, sans-serif;
                                    font-size: 16px;
                                    font-weight: 400;
                                    hyphens: auto;
                                    line-height: 16px;
                                    margin: 0;
                                    mso-line-height-rule: exactly;
                                    padding-bottom: 0;
                                    padding-left: 0;
                                    padding-right: 0;
                                    padding-top: 0;
                                    text-align: left;
                                    vertical-align: top;
                                    word-wrap: break-word;
                                  "
                                >
                                  &nbsp;
                                </td>
                              </tr>
                            </tbody>
                          </table>
                          <table
                            class="row"
                            style="
                              max-width: 600px;
                              border-collapse: collapse;
                              border-spacing: 0;
                              display: table;
                              padding: 0;
                              padding-bottom: 0;
                              padding-left: 0;
                              padding-right: 0;
                              padding-top: 0;
                              position: relative;
                              text-align: left;
                              vertical-align: top;
                              width: 100%;
                            "
                          >
                            <tbody>
                              <tr
                                style="
                                  padding-bottom: 0;
                                  padding-left: 0;
                                  padding-right: 0;
                                  padding-top: 0;
                                  text-align: left;
                                  vertical-align: top;
                                "
                              >
                                <th
                                  class="small-12 large-12 columns first last"
                                  style="
                                    -moz-hyphens: auto;
                                    -webkit-hyphens: auto;
                                    margin: 0 auto;
                                    border-collapse: collapse !important;
                                    color: #0a0a0a;
                                    font-family: Helvetica, Arial, sans-serif;
                                    font-size: 16px;
                                    font-weight: 400;
                                    hyphens: auto;
                                    line-height: 1.3;
                                    margin: 0 auto;
                                    padding-bottom: 16px;
                                    padding-left: 30px;
                                    padding-right: 30px;
                                    padding-top: 0;
                                    text-align: left;
                                    vertical-align: top;
                                    width: 550px;
                                    word-wrap: break-word;
                                  "
                                >
                                  <table
                                    style="
                                      border-collapse: collapse;
                                      border-spacing: 0;
                                      padding-bottom: 0;
                                      padding-left: 0;
                                      padding-right: 0;
                                      padding-top: 0;
                                      text-align: left;
                                      vertical-align: top;
                                      width: 100%;
                                    "
                                  >
                                    <tbody>
                                      <tr
                                        style="
                                          padding-bottom: 0;
                                          padding-left: 0;
                                          padding-right: 0;
                                          padding-top: 0;
                                          text-align: left;
                                          vertical-align: top;
                                        "
                                      >
                                        <th
                                          style="
                                            -moz-hyphens: auto;
                                            -webkit-hyphens: auto;
                                            margin: 0;
                                            border-collapse: collapse !important;
                                            color: #0a0a0a;
                                            font-family: Helvetica, Arial,
                                              sans-serif;
                                            font-size: 16px;
                                            font-weight: 400;
                                            hyphens: auto;
                                            line-height: 1.3;
                                            margin: 0;
                                            padding-bottom: 0;
                                            padding-left: 0;
                                            padding-right: 0;
                                            padding-top: 0;
                                            text-align: left;
                                            vertical-align: top;
                                            word-wrap: break-word;
                                          "
                                        >
                                          <!--<center
                                            style="min-width: 490px; width: 100%"
                                          >-->
                                          <center style="width: 100%">
                                            <img
                                              :src="
                                                storageUrl +
                                                '/img/projects/tipologies/' +
                                                page.data.lead
                                                  .project_type_department_rel
                                                  .image
                                              "
                                              height="auto"
                                              alt
                                              align="center"
                                              class="float-center"
                                              style="
                                                -ms-interpolation-mode: bicubic;
                                                margin: 0 auto;
                                                clear: both;
                                                display: block;
                                                float: none;
                                                margin: 0 auto;
                                                max-width: 100%;
                                                outline: 0;
                                                text-align: center;
                                                text-decoration: none;
                                                width: auto;
                                              "
                                            />
                                          </center>
                                        </th>
                                        <th
                                          class="expander"
                                          style="
                                            -moz-hyphens: auto;
                                            -webkit-hyphens: auto;
                                            margin: 0;
                                            border-collapse: collapse !important;
                                            color: #0a0a0a;
                                            font-family: Helvetica, Arial,
                                              sans-serif;
                                            font-size: 16px;
                                            font-weight: 400;
                                            hyphens: auto;
                                            line-height: 1.3;
                                            margin: 0;
                                            padding: 0 !important;
                                            padding-bottom: 0;
                                            padding-left: 0;
                                            padding-right: 0;
                                            padding-top: 0;
                                            text-align: left;
                                            vertical-align: top;
                                            visibility: hidden;
                                            width: 0;
                                            word-wrap: break-word;
                                          "
                                        ></th>
                                      </tr>
                                    </tbody>
                                  </table>
                                </th>
                              </tr>
                            </tbody>
                          </table>
                          <table
                            class="spacer"
                            style="
                              border-collapse: collapse;
                              border-spacing: 0;
                              padding-bottom: 0;
                              padding-left: 0;
                              padding-right: 0;
                              padding-top: 0;
                              text-align: left;
                              vertical-align: top;
                              width: 100%;
                            "
                          >
                            <tbody>
                              <tr
                                style="
                                  padding-bottom: 0;
                                  padding-left: 0;
                                  padding-right: 0;
                                  padding-top: 0;
                                  text-align: left;
                                  vertical-align: top;
                                "
                              >
                                <td
                                  height="12"
                                  style="
                                    -moz-hyphens: auto;
                                    -webkit-hyphens: auto;
                                    margin: 0;
                                    border-collapse: collapse !important;
                                    color: #0a0a0a;
                                    font-family: Helvetica, Arial, sans-serif;
                                    font-size: 12px;
                                    font-weight: 400;
                                    hyphens: auto;
                                    line-height: 12px;
                                    margin: 0;
                                    mso-line-height-rule: exactly;
                                    padding-bottom: 0;
                                    padding-left: 0;
                                    padding-right: 0;
                                    padding-top: 0;
                                    text-align: left;
                                    vertical-align: top;
                                    word-wrap: break-word;
                                  "
                                >
                                  &nbsp;
                                </td>
                              </tr>
                            </tbody>
                          </table>
                          <table
                            v-if="
                              page.data.lead.project_rel &&
                              page.data.lead.project_rel.financing_options_rel
                                .length
                            "
                            class="row"
                            style="
                              max-width: 600px;
                              border-collapse: collapse;
                              border-spacing: 0;
                              display: table;
                              padding: 0;
                              padding-bottom: 0;
                              padding-left: 0;
                              padding-right: 0;
                              padding-top: 0;
                              position: relative;
                              text-align: left;
                              vertical-align: top;
                              width: 100%;
                            "
                          >
                            <tbody>
                              <tr
                                style="
                                  padding-bottom: 0;
                                  padding-left: 0;
                                  padding-right: 0;
                                  padding-top: 0;
                                  text-align: left;
                                  vertical-align: top;
                                "
                              >
                                <th
                                  class="small-12 large-12 columns first last"
                                  style="
                                    -moz-hyphens: auto;
                                    -webkit-hyphens: auto;
                                    margin: 0 auto;
                                    border-collapse: collapse !important;
                                    color: #0a0a0a;
                                    font-family: Helvetica, Arial, sans-serif;
                                    font-size: 16px;
                                    font-weight: 400;
                                    hyphens: auto;
                                    line-height: 1.3;
                                    margin: 0 auto;
                                    padding-bottom: 16px;
                                    padding-left: 30px;
                                    padding-right: 30px;
                                    padding-top: 0;
                                    text-align: left;
                                    vertical-align: top;
                                    width: 550px;
                                    word-wrap: break-word;
                                  "
                                >
                                  <table
                                    style="
                                      border-collapse: collapse;
                                      border-spacing: 0;
                                      padding-bottom: 0;
                                      padding-left: 0;
                                      padding-right: 0;
                                      padding-top: 0;
                                      text-align: left;
                                      vertical-align: top;
                                      width: 100%;
                                    "
                                  >
                                    <tbody>
                                      <tr
                                        style="
                                          padding-bottom: 0;
                                          padding-left: 0;
                                          padding-right: 0;
                                          padding-top: 0;
                                          text-align: left;
                                          vertical-align: top;
                                        "
                                      >
                                        <th
                                          style="
                                            -moz-hyphens: auto;
                                            -webkit-hyphens: auto;
                                            margin: 0;
                                            border-collapse: collapse !important;
                                            color: #0a0a0a;
                                            font-family: Helvetica, Arial,
                                              sans-serif;
                                            font-size: 16px;
                                            font-weight: 400;
                                            hyphens: auto;
                                            line-height: 1.3;
                                            margin: 0;
                                            padding-bottom: 0;
                                            padding-left: 0;
                                            padding-right: 0;
                                            padding-top: 0;
                                            text-align: left;
                                            vertical-align: top;
                                            word-wrap: break-word;
                                          "
                                        >
                                          <h5
                                            class="text-primary"
                                            style="
                                              margin: 0;
                                              margin-bottom: 10px;
                                              color: #0b6fa6;
                                              font-family: Helvetica, Arial,
                                                sans-serif;
                                              font-size: 20px;
                                              font-weight: 400;
                                              line-height: 1.3;
                                              margin: 0;
                                              margin-bottom: 10px;
                                              padding-bottom: 0;
                                              padding-left: 0;
                                              padding-right: 0;
                                              padding-top: 0;
                                              text-align: left;
                                              word-wrap: normal;
                                            "
                                          >
                                            <strong
                                              >Opciones de
                                              Financiamiento</strong
                                            >
                                          </h5>
                                        </th>
                                        <th
                                          class="expander"
                                          style="
                                            -moz-hyphens: auto;
                                            -webkit-hyphens: auto;
                                            margin: 0;
                                            border-collapse: collapse !important;
                                            color: #0a0a0a;
                                            font-family: Helvetica, Arial,
                                              sans-serif;
                                            font-size: 16px;
                                            font-weight: 400;
                                            hyphens: auto;
                                            line-height: 1.3;
                                            margin: 0;
                                            padding: 0 !important;
                                            padding-bottom: 0;
                                            padding-left: 0;
                                            padding-right: 0;
                                            padding-top: 0;
                                            text-align: left;
                                            vertical-align: top;
                                            visibility: hidden;
                                            width: 0;
                                            word-wrap: break-word;
                                          "
                                        ></th>
                                      </tr>
                                    </tbody>
                                  </table>
                                </th>
                              </tr>
                            </tbody>
                          </table>
                          <table
                            class="row"
                            style="
                              max-width: 600px;
                              border-collapse: collapse;
                              border-spacing: 0;
                              display: table;
                              padding: 0;
                              padding-bottom: 0;
                              padding-left: 0;
                              padding-right: 0;
                              padding-top: 0;
                              position: relative;
                              text-align: left;
                              vertical-align: top;
                              width: 100%;
                            "
                          >
                            <tbody>
                              <tr
                                style="
                                  padding-bottom: 0;
                                  padding-left: 0;
                                  padding-right: 0;
                                  padding-top: 0;
                                  text-align: left;
                                  vertical-align: top;
                                "
                              >
                                <th
                                  class="small-12 large-12 columns first last"
                                  style="
                                    -moz-hyphens: auto;
                                    -webkit-hyphens: auto;
                                    margin: 0 auto;
                                    border-collapse: collapse !important;
                                    color: #0a0a0a;
                                    font-family: Helvetica, Arial, sans-serif;
                                    font-size: 16px;
                                    font-weight: 400;
                                    hyphens: auto;
                                    line-height: 1.3;
                                    margin: 0 auto;
                                    padding-bottom: 0;
                                    padding-left: 30px;
                                    padding-right: 30px;
                                    padding-top: 0;
                                    text-align: left;
                                    vertical-align: top;
                                    width: 550px;
                                    word-wrap: break-word;
                                  "
                                >
                                  <table
                                    style="
                                      border-collapse: collapse;
                                      border-spacing: 0;
                                      padding-bottom: 0;
                                      padding-left: 0;
                                      padding-right: 0;
                                      padding-top: 0;
                                      text-align: left;
                                      vertical-align: top;
                                      width: 100%;
                                    "
                                  >
                                    <tbody>
                                      <tr
                                        style="
                                          padding-bottom: 0;
                                          padding-left: 0;
                                          padding-right: 0;
                                          padding-top: 0;
                                          text-align: left;
                                          vertical-align: top;
                                        "
                                      >
                                        <th
                                          style="
                                            -moz-hyphens: auto;
                                            -webkit-hyphens: auto;
                                            margin: 0;
                                            border-collapse: collapse !important;
                                            color: #0a0a0a;
                                            font-family: Helvetica, Arial,
                                              sans-serif;
                                            font-size: 16px;
                                            font-weight: 400;
                                            hyphens: auto;
                                            line-height: 1.3;
                                            margin: 0;
                                            padding-bottom: 0;
                                            padding-left: 0;
                                            padding-right: 0;
                                            padding-top: 0;
                                            text-align: left;
                                            vertical-align: top;
                                            word-wrap: break-word;
                                          "
                                        >
                                          <ol
                                            style="
                                              padding-top: 0;
                                              margin-top: 0;
                                              margin-bottom: 0;
                                              padding-right: 20px;
                                              padding-left: 20px;
                                            "
                                          >
                                            <li
                                              style="margin-bottom: 0.5rem"
                                              v-for="el in page.data.lead
                                                .project_rel
                                                .financing_options_rel"
                                              :key="el.id"
                                            >
                                              {{ el.name }}
                                            </li>
                                          </ol>
                                        </th>
                                        <th
                                          class="expander"
                                          style="
                                            -moz-hyphens: auto;
                                            -webkit-hyphens: auto;
                                            margin: 0;
                                            border-collapse: collapse !important;
                                            color: #0a0a0a;
                                            font-family: Helvetica, Arial,
                                              sans-serif;
                                            font-size: 16px;
                                            font-weight: 400;
                                            hyphens: auto;
                                            line-height: 1.3;
                                            margin: 0;
                                            padding: 0 !important;
                                            padding-bottom: 0;
                                            padding-left: 0;
                                            padding-right: 0;
                                            padding-top: 0;
                                            text-align: left;
                                            vertical-align: top;
                                            visibility: hidden;
                                            width: 0;
                                            word-wrap: break-word;
                                          "
                                        ></th>
                                      </tr>
                                    </tbody>
                                  </table>
                                </th>
                              </tr>
                            </tbody>
                          </table>
                          <table
                            class="spacer"
                            style="
                              border-collapse: collapse;
                              border-spacing: 0;
                              padding-bottom: 0;
                              padding-left: 0;
                              padding-right: 0;
                              padding-top: 0;
                              text-align: left;
                              vertical-align: top;
                              width: 100%;
                            "
                          >
                            <tbody>
                              <tr
                                style="
                                  padding-bottom: 0;
                                  padding-left: 0;
                                  padding-right: 0;
                                  padding-top: 0;
                                  text-align: left;
                                  vertical-align: top;
                                "
                              >
                                <td
                                  height="24"
                                  style="
                                    -moz-hyphens: auto;
                                    -webkit-hyphens: auto;
                                    margin: 0;
                                    border-collapse: collapse !important;
                                    color: #0a0a0a;
                                    font-family: Helvetica, Arial, sans-serif;
                                    font-size: 24px;
                                    font-weight: 400;
                                    hyphens: auto;
                                    line-height: 24px;
                                    margin: 0;
                                    mso-line-height-rule: exactly;
                                    padding-bottom: 0;
                                    padding-left: 0;
                                    padding-right: 0;
                                    padding-top: 0;
                                    text-align: left;
                                    vertical-align: top;
                                    word-wrap: break-word;
                                  "
                                >
                                  &nbsp;
                                </td>
                              </tr>
                            </tbody>
                          </table>
                          <table
                            v-if="
                              page.data.lead.project_rel.condition_quotation
                            "
                            class="row"
                            style="
                              max-width: 600px;
                              border-collapse: collapse;
                              border-spacing: 0;
                              display: table;
                              padding: 0;
                              padding-bottom: 0;
                              padding-left: 0;
                              padding-right: 0;
                              padding-top: 0;
                              position: relative;
                              text-align: left;
                              vertical-align: top;
                              width: 100%;
                            "
                          >
                            <tbody>
                              <tr
                                style="
                                  padding-bottom: 0;
                                  padding-left: 0;
                                  padding-right: 0;
                                  padding-top: 0;
                                  text-align: left;
                                  vertical-align: top;
                                "
                              >
                                <th
                                  class="small-12 large-12 columns first last"
                                  style="
                                    -moz-hyphens: auto;
                                    -webkit-hyphens: auto;
                                    margin: 0 auto;
                                    border-collapse: collapse !important;
                                    color: #0a0a0a;
                                    font-family: Helvetica, Arial, sans-serif;
                                    font-size: 16px;
                                    font-weight: 400;
                                    hyphens: auto;
                                    line-height: 1.3;
                                    margin: 0 auto;
                                    padding-bottom: 16px;
                                    padding-left: 30px;
                                    padding-right: 30px;
                                    padding-top: 0;
                                    text-align: left;
                                    vertical-align: top;
                                    width: 550px;
                                    word-wrap: break-word;
                                  "
                                >
                                  <table
                                    style="
                                      border-collapse: collapse;
                                      border-spacing: 0;
                                      padding-bottom: 0;
                                      padding-left: 0;
                                      padding-right: 0;
                                      padding-top: 0;
                                      text-align: left;
                                      vertical-align: top;
                                      width: 100%;
                                    "
                                  >
                                    <tbody>
                                      <tr
                                        style="
                                          padding-bottom: 0;
                                          padding-left: 0;
                                          padding-right: 0;
                                          padding-top: 0;
                                          text-align: left;
                                          vertical-align: top;
                                        "
                                      >
                                        <th
                                          style="
                                            -moz-hyphens: auto;
                                            -webkit-hyphens: auto;
                                            margin: 0;
                                            border-collapse: collapse !important;
                                            color: #0a0a0a;
                                            font-family: Helvetica, Arial,
                                              sans-serif;
                                            font-size: 16px;
                                            font-weight: 400;
                                            hyphens: auto;
                                            line-height: 1.3;
                                            margin: 0;
                                            padding-bottom: 0;
                                            padding-left: 0;
                                            padding-right: 0;
                                            padding-top: 0;
                                            text-align: left;
                                            vertical-align: top;
                                            word-wrap: break-word;
                                          "
                                        >
                                          <h5
                                            class="text-primary"
                                            style="
                                              margin: 0;
                                              margin-bottom: 0;
                                              color: #0b6fa6;
                                              font-family: Helvetica, Arial,
                                                sans-serif;
                                              font-size: 20px;
                                              font-weight: 400;
                                              line-height: 1.3;
                                              margin: 0;
                                              margin-bottom: 0;
                                              padding-bottom: 0;
                                              padding-left: 0;
                                              padding-right: 0;
                                              padding-top: 0;
                                              text-align: left;
                                              word-wrap: normal;
                                            "
                                          >
                                            <strong
                                              >Condiciones de la
                                              Proforma</strong
                                            >
                                          </h5>
                                        </th>
                                        <th
                                          class="expander"
                                          style="
                                            -moz-hyphens: auto;
                                            -webkit-hyphens: auto;
                                            margin: 0;
                                            border-collapse: collapse !important;
                                            color: #0a0a0a;
                                            font-family: Helvetica, Arial,
                                              sans-serif;
                                            font-size: 16px;
                                            font-weight: 400;
                                            hyphens: auto;
                                            line-height: 1.3;
                                            margin: 0;
                                            padding: 0 !important;
                                            padding-bottom: 0;
                                            padding-left: 0;
                                            padding-right: 0;
                                            padding-top: 0;
                                            text-align: left;
                                            vertical-align: top;
                                            visibility: hidden;
                                            width: 0;
                                            word-wrap: break-word;
                                          "
                                        ></th>
                                      </tr>
                                    </tbody>
                                  </table>
                                </th>
                              </tr>
                            </tbody>
                          </table>
                          <table
                            class="row"
                            style="
                              max-width: 600px;
                              border-collapse: collapse;
                              border-spacing: 0;
                              display: table;
                              padding: 0;
                              padding-bottom: 0;
                              padding-left: 0;
                              padding-right: 0;
                              padding-top: 0;
                              position: relative;
                              text-align: left;
                              vertical-align: top;
                              width: 100%;
                            "
                          >
                            <tbody>
                              <tr
                                style="
                                  padding-bottom: 0;
                                  padding-left: 0;
                                  padding-right: 0;
                                  padding-top: 0;
                                  text-align: left;
                                  vertical-align: top;
                                "
                              >
                                <th
                                  class="small-12 large-12 columns first last"
                                  style="
                                    -moz-hyphens: auto;
                                    -webkit-hyphens: auto;
                                    margin: 0 auto;
                                    border-collapse: collapse !important;
                                    color: #0a0a0a;
                                    font-family: Helvetica, Arial, sans-serif;
                                    font-size: 16px;
                                    font-weight: 400;
                                    hyphens: auto;
                                    line-height: 1.3;
                                    margin: 0 auto;
                                    padding-bottom: 16px;
                                    padding-left: 30px;
                                    padding-right: 30px;
                                    padding-top: 0;
                                    text-align: left;
                                    vertical-align: top;
                                    width: 550px;
                                    word-wrap: break-word;
                                  "
                                >
                                  <table
                                    style="
                                      border-collapse: collapse;
                                      border-spacing: 0;
                                      padding-bottom: 0;
                                      padding-left: 0;
                                      padding-right: 0;
                                      padding-top: 0;
                                      text-align: left;
                                      vertical-align: top;
                                      width: 100%;
                                    "
                                  >
                                    <tbody>
                                      <tr
                                        style="
                                          padding-bottom: 0;
                                          padding-left: 0;
                                          padding-right: 0;
                                          padding-top: 0;
                                          text-align: left;
                                          vertical-align: top;
                                        "
                                      >
                                        <th
                                          style="
                                            -moz-hyphens: auto;
                                            -webkit-hyphens: auto;
                                            margin: 0;
                                            border-collapse: collapse !important;
                                            color: #0a0a0a;
                                            font-family: Helvetica, Arial,
                                              sans-serif;
                                            font-size: 16px;
                                            font-weight: 400;
                                            hyphens: auto;
                                            line-height: 1.3;
                                            margin: 0;
                                            padding-bottom: 0;
                                            padding-left: 0;
                                            padding-right: 0;
                                            padding-top: 0;
                                            text-align: left;
                                            vertical-align: top;
                                            word-wrap: break-word;
                                          "
                                        >
                                          <div
                                            style="
                                              margin: 0;
                                              margin-bottom: 10px;
                                              color: #0a0a0a;
                                              font-family: Helvetica, Arial,
                                                sans-serif;
                                              font-size: 16px;
                                              font-weight: 400;
                                              line-height: 1.3;
                                              margin: 0;
                                              margin-bottom: 10px;
                                              padding-bottom: 0;
                                              padding-left: 0;
                                              padding-right: 0;
                                              padding-top: 0;
                                              text-align: left;
                                            "
                                            class="email_text"
                                            v-html="
                                              page.data.lead.project_rel
                                                .condition_quotation
                                            "
                                          ></div>
                                        </th>
                                        <th
                                          class="expander"
                                          style="
                                            -moz-hyphens: auto;
                                            -webkit-hyphens: auto;
                                            margin: 0;
                                            border-collapse: collapse !important;
                                            color: #0a0a0a;
                                            font-family: Helvetica, Arial,
                                              sans-serif;
                                            font-size: 16px;
                                            font-weight: 400;
                                            hyphens: auto;
                                            line-height: 1.3;
                                            margin: 0;
                                            padding: 0 !important;
                                            padding-bottom: 0;
                                            padding-left: 0;
                                            padding-right: 0;
                                            padding-top: 0;
                                            text-align: left;
                                            vertical-align: top;
                                            visibility: hidden;
                                            width: 0;
                                            word-wrap: break-word;
                                          "
                                        ></th>
                                      </tr>
                                    </tbody>
                                  </table>
                                </th>
                              </tr>
                            </tbody>
                          </table>
                          <table
                            class="spacer"
                            style="
                              border-collapse: collapse;
                              border-spacing: 0;
                              padding-bottom: 0;
                              padding-left: 0;
                              padding-right: 0;
                              padding-top: 0;
                              text-align: left;
                              vertical-align: top;
                              width: 100%;
                            "
                          >
                            <tbody>
                              <tr
                                style="
                                  padding-bottom: 0;
                                  padding-left: 0;
                                  padding-right: 0;
                                  padding-top: 0;
                                  text-align: left;
                                  vertical-align: top;
                                "
                              >
                                <td
                                  height="24"
                                  style="
                                    -moz-hyphens: auto;
                                    -webkit-hyphens: auto;
                                    margin: 0;
                                    border-collapse: collapse !important;
                                    color: #0a0a0a;
                                    font-family: Helvetica, Arial, sans-serif;
                                    font-size: 24px;
                                    font-weight: 400;
                                    hyphens: auto;
                                    line-height: 24px;
                                    margin: 0;
                                    mso-line-height-rule: exactly;
                                    padding-bottom: 0;
                                    padding-left: 0;
                                    padding-right: 0;
                                    padding-top: 0;
                                    text-align: left;
                                    vertical-align: top;
                                    word-wrap: break-word;
                                  "
                                >
                                  &nbsp;
                                </td>
                              </tr>
                            </tbody>
                          </table>
                          <table
                            class="row"
                            style="
                              max-width: 600px;
                              border-collapse: collapse;
                              border-spacing: 0;
                              display: table;
                              padding: 0;
                              padding-bottom: 0;
                              padding-left: 0;
                              padding-right: 0;
                              padding-top: 0;
                              position: relative;
                              text-align: left;
                              vertical-align: top;
                              width: 100%;
                            "
                          >
                            <tbody>
                              <tr
                                style="
                                  padding-bottom: 0;
                                  padding-left: 0;
                                  padding-right: 0;
                                  padding-top: 0;
                                  text-align: left;
                                  vertical-align: top;
                                "
                              >
                                <th
                                  class="small-12 large-12 columns first last"
                                  style="
                                    -moz-hyphens: auto;
                                    -webkit-hyphens: auto;
                                    margin: 0 auto;
                                    border-collapse: collapse !important;
                                    color: #0a0a0a;
                                    font-family: Helvetica, Arial, sans-serif;
                                    font-size: 16px;
                                    font-weight: 400;
                                    hyphens: auto;
                                    line-height: 1.3;
                                    margin: 0 auto;
                                    padding-bottom: 16px;
                                    padding-left: 30px;
                                    padding-right: 30px;
                                    padding-top: 0;
                                    text-align: left;
                                    vertical-align: top;
                                    width: 550px;
                                    word-wrap: break-word;
                                  "
                                >
                                  <table
                                    style="
                                      border-collapse: collapse;
                                      border-spacing: 0;
                                      padding-bottom: 0;
                                      padding-left: 0;
                                      padding-right: 0;
                                      padding-top: 0;
                                      text-align: left;
                                      vertical-align: top;
                                      width: 100%;
                                    "
                                  >
                                    <tbody>
                                      <tr
                                        style="
                                          padding-bottom: 0;
                                          padding-left: 0;
                                          padding-right: 0;
                                          padding-top: 0;
                                          text-align: left;
                                          vertical-align: top;
                                        "
                                      >
                                        <th
                                          style="
                                            -moz-hyphens: auto;
                                            -webkit-hyphens: auto;
                                            margin: 0;
                                            border-collapse: collapse !important;
                                            color: #0a0a0a;
                                            font-family: Helvetica, Arial,
                                              sans-serif;
                                            font-size: 16px;
                                            font-weight: 400;
                                            hyphens: auto;
                                            line-height: 1.3;
                                            margin: 0;
                                            padding-bottom: 0;
                                            padding-left: 0;
                                            padding-right: 0;
                                            padding-top: 0;
                                            text-align: left;
                                            vertical-align: top;
                                            word-wrap: break-word;
                                          "
                                        >
                                          <h5
                                            class="text-primary"
                                            style="
                                              margin: 0;
                                              margin-bottom: 10px;
                                              color: #0b6fa6;
                                              font-family: Helvetica, Arial,
                                                sans-serif;
                                              font-size: 20px;
                                              font-weight: 400;
                                              line-height: 1.3;
                                              margin: 0;
                                              margin-bottom: 0;
                                              padding-bottom: 0;
                                              padding-left: 0;
                                              padding-right: 0;
                                              padding-top: 0;
                                              text-align: left;
                                              word-wrap: normal;
                                            "
                                          >
                                            <strong
                                              >¿Tienes alguna duda?<br />Contacte
                                              con nuestro ejecutivo
                                              comercial</strong
                                            >
                                          </h5>
                                        </th>
                                        <th
                                          class="expander"
                                          style="
                                            -moz-hyphens: auto;
                                            -webkit-hyphens: auto;
                                            margin: 0;
                                            border-collapse: collapse !important;
                                            color: #0a0a0a;
                                            font-family: Helvetica, Arial,
                                              sans-serif;
                                            font-size: 16px;
                                            font-weight: 400;
                                            hyphens: auto;
                                            line-height: 1.3;
                                            margin: 0;
                                            padding: 0 !important;
                                            padding-bottom: 0;
                                            padding-left: 0;
                                            padding-right: 0;
                                            padding-top: 0;
                                            text-align: left;
                                            vertical-align: top;
                                            visibility: hidden;
                                            width: 0;
                                            word-wrap: break-word;
                                          "
                                        ></th>
                                      </tr>
                                    </tbody>
                                  </table>
                                </th>
                              </tr>
                            </tbody>
                          </table>
                          <table
                            class="row"
                            style="
                              max-width: 600px;
                              border-collapse: collapse;
                              border-spacing: 0;
                              display: table;
                              padding: 0;
                              padding-bottom: 0;
                              padding-left: 0;
                              padding-right: 0;
                              padding-top: 0;
                              position: relative;
                              text-align: left;
                              vertical-align: top;
                              width: 100%;
                            "
                          >
                            <tbody>
                              <tr
                                style="
                                  padding-bottom: 0;
                                  padding-left: 0;
                                  padding-right: 0;
                                  padding-top: 0;
                                  text-align: left;
                                  vertical-align: top;
                                "
                              >
                                <th
                                  class="small-12 large-12 columns first last"
                                  style="
                                    -moz-hyphens: auto;
                                    -webkit-hyphens: auto;
                                    margin: 0 auto;
                                    border-collapse: collapse !important;
                                    color: #0a0a0a;
                                    font-family: Helvetica, Arial, sans-serif;
                                    font-size: 16px;
                                    font-weight: 400;
                                    hyphens: auto;
                                    line-height: 1.3;
                                    margin: 0 auto;
                                    padding-bottom: 16px;
                                    padding-left: 30px;
                                    padding-right: 30px;
                                    padding-top: 0;
                                    text-align: left;
                                    vertical-align: top;
                                    width: 550px;
                                    word-wrap: break-word;
                                  "
                                >
                                  <table
                                    style="
                                      border-collapse: collapse;
                                      border-spacing: 0;
                                      padding-bottom: 0;
                                      padding-left: 0;
                                      padding-right: 0;
                                      padding-top: 0;
                                      text-align: left;
                                      vertical-align: top;
                                      width: 100%;
                                    "
                                  >
                                    <tbody>
                                      <tr
                                        style="
                                          padding-bottom: 0;
                                          padding-left: 0;
                                          padding-right: 0;
                                          padding-top: 0;
                                          text-align: left;
                                          vertical-align: top;
                                        "
                                      >
                                        <th
                                          style="
                                            -moz-hyphens: auto;
                                            -webkit-hyphens: auto;
                                            margin: 0;
                                            border-collapse: collapse !important;
                                            color: #0a0a0a;
                                            font-family: Helvetica, Arial,
                                              sans-serif;
                                            font-size: 16px;
                                            font-weight: 400;
                                            hyphens: auto;
                                            line-height: 1.3;
                                            margin: 0;
                                            padding-bottom: 0;
                                            padding-left: 0;
                                            padding-right: 0;
                                            padding-top: 0;
                                            text-align: left;
                                            vertical-align: top;
                                            word-wrap: break-word;
                                          "
                                        >
                                          <table
                                            style="
                                              border-collapse: collapse;
                                              border-spacing: 0;
                                              padding-bottom: 0;
                                              padding-left: 0;
                                              padding-right: 0;
                                              padding-top: 0;
                                              text-align: left;
                                              vertical-align: top;
                                              width: 100%;
                                            "
                                          >
                                            <tr
                                              style="
                                                padding-bottom: 0;
                                                padding-left: 0;
                                                padding-right: 0;
                                                padding-top: 0;
                                                text-align: left;
                                                vertical-align: top;
                                              "
                                            >
                                              <td
                                                style="
                                                  -moz-hyphens: auto;
                                                  -webkit-hyphens: auto;
                                                  margin: 0;
                                                  border-collapse: collapse !important;
                                                  color: #7c7c7c;
                                                  font-family: Helvetica, Arial,
                                                    sans-serif;
                                                  font-size: 16px;
                                                  font-weight: 400;
                                                  hyphens: auto;
                                                  line-height: 1.3;
                                                  margin: 0;
                                                  padding-bottom: 0;
                                                  padding-left: 0;
                                                  padding-right: 0;
                                                  padding-top: 0;
                                                  text-align: left;
                                                  vertical-align: top;
                                                  width: 40%;
                                                  word-wrap: break-word;
                                                "
                                              >
                                                <table
                                                  class="spacer"
                                                  style="
                                                    border-collapse: collapse;
                                                    border-spacing: 0;
                                                    padding-bottom: 0;
                                                    padding-left: 0;
                                                    padding-right: 0;
                                                    padding-top: 0;
                                                    text-align: left;
                                                    vertical-align: top;
                                                    width: 100%;
                                                  "
                                                >
                                                  <tbody>
                                                    <tr
                                                      style="
                                                        padding-bottom: 0;
                                                        padding-left: 0;
                                                        padding-right: 0;
                                                        padding-top: 0;
                                                        text-align: left;
                                                        vertical-align: top;
                                                      "
                                                    >
                                                      <td
                                                        height="10"
                                                        style="
                                                          -moz-hyphens: auto;
                                                          -webkit-hyphens: auto;
                                                          margin: 0;
                                                          border-collapse: collapse !important;
                                                          color: #0a0a0a;
                                                          font-family: Helvetica,
                                                            Arial, sans-serif;
                                                          font-size: 10px;
                                                          font-weight: 400;
                                                          hyphens: auto;
                                                          line-height: 10px;
                                                          margin: 0;
                                                          mso-line-height-rule: exactly;
                                                          padding-bottom: 0;
                                                          padding-left: 0;
                                                          padding-right: 0;
                                                          padding-top: 0;
                                                          text-align: left;
                                                          vertical-align: top;
                                                          word-wrap: break-word;
                                                        "
                                                      >
                                                        &nbsp;
                                                      </td>
                                                    </tr>
                                                  </tbody>
                                                </table>
                                                Nombre:
                                                <table
                                                  class="spacer"
                                                  style="
                                                    border-collapse: collapse;
                                                    border-spacing: 0;
                                                    padding-bottom: 0;
                                                    padding-left: 0;
                                                    padding-right: 0;
                                                    padding-top: 0;
                                                    text-align: left;
                                                    vertical-align: top;
                                                    width: 100%;
                                                  "
                                                >
                                                  <tbody>
                                                    <tr
                                                      style="
                                                        padding-bottom: 0;
                                                        padding-left: 0;
                                                        padding-right: 0;
                                                        padding-top: 0;
                                                        text-align: left;
                                                        vertical-align: top;
                                                      "
                                                    >
                                                      <td
                                                        height="10"
                                                        style="
                                                          -moz-hyphens: auto;
                                                          -webkit-hyphens: auto;
                                                          margin: 0;
                                                          border-collapse: collapse !important;
                                                          color: #0a0a0a;
                                                          font-family: Helvetica,
                                                            Arial, sans-serif;
                                                          font-size: 10px;
                                                          font-weight: 400;
                                                          hyphens: auto;
                                                          line-height: 10px;
                                                          margin: 0;
                                                          mso-line-height-rule: exactly;
                                                          padding-bottom: 0;
                                                          padding-left: 0;
                                                          padding-right: 0;
                                                          padding-top: 0;
                                                          text-align: left;
                                                          vertical-align: top;
                                                          word-wrap: break-word;
                                                        "
                                                      >
                                                        &nbsp;
                                                      </td>
                                                    </tr>
                                                  </tbody>
                                                </table>
                                              </td>
                                              <td
                                                style="
                                                  -moz-hyphens: auto;
                                                  -webkit-hyphens: auto;
                                                  margin: 0;
                                                  border-collapse: collapse !important;
                                                  color: #0a0a0a;
                                                  font-family: Helvetica, Arial,
                                                    sans-serif;
                                                  font-size: 16px;
                                                  font-weight: 400;
                                                  hyphens: auto;
                                                  line-height: 1.3;
                                                  margin: 0;
                                                  padding-bottom: 0;
                                                  padding-left: 0;
                                                  padding-right: 0;
                                                  padding-top: 0;
                                                  text-align: left;
                                                  vertical-align: top;
                                                  word-wrap: break-word;
                                                "
                                              >
                                                <strong>
                                                  <table
                                                    class="spacer"
                                                    style="
                                                      border-collapse: collapse;
                                                      border-spacing: 0;
                                                      padding-bottom: 0;
                                                      padding-left: 0;
                                                      padding-right: 0;
                                                      padding-top: 0;
                                                      text-align: left;
                                                      vertical-align: top;
                                                      width: 100%;
                                                    "
                                                  >
                                                    <tbody>
                                                      <tr
                                                        style="
                                                          padding-bottom: 0;
                                                          padding-left: 0;
                                                          padding-right: 0;
                                                          padding-top: 0;
                                                          text-align: left;
                                                          vertical-align: top;
                                                        "
                                                      >
                                                        <td
                                                          height="10"
                                                          style="
                                                            -moz-hyphens: auto;
                                                            -webkit-hyphens: auto;
                                                            margin: 0;
                                                            border-collapse: collapse !important;
                                                            color: #0a0a0a;
                                                            font-family: Helvetica,
                                                              Arial, sans-serif;
                                                            font-size: 10px;
                                                            font-weight: 400;
                                                            hyphens: auto;
                                                            line-height: 10px;
                                                            margin: 0;
                                                            mso-line-height-rule: exactly;
                                                            padding-bottom: 0;
                                                            padding-left: 0;
                                                            padding-right: 0;
                                                            padding-top: 0;
                                                            text-align: left;
                                                            vertical-align: top;
                                                            word-wrap: break-word;
                                                          "
                                                        >
                                                          &nbsp;
                                                        </td>
                                                      </tr>
                                                    </tbody>
                                                  </table>
                                                  {{
                                                    page.data.lead.advisor_rel
                                                      .name
                                                  }}
                                                </strong>
                                                <table
                                                  class="spacer"
                                                  style="
                                                    border-collapse: collapse;
                                                    border-spacing: 0;
                                                    padding-bottom: 0;
                                                    padding-left: 0;
                                                    padding-right: 0;
                                                    padding-top: 0;
                                                    text-align: left;
                                                    vertical-align: top;
                                                    width: 100%;
                                                  "
                                                >
                                                  <tbody>
                                                    <tr
                                                      style="
                                                        padding-bottom: 0;
                                                        padding-left: 0;
                                                        padding-right: 0;
                                                        padding-top: 0;
                                                        text-align: left;
                                                        vertical-align: top;
                                                      "
                                                    >
                                                      <td
                                                        height="10"
                                                        style="
                                                          -moz-hyphens: auto;
                                                          -webkit-hyphens: auto;
                                                          margin: 0;
                                                          border-collapse: collapse !important;
                                                          color: #0a0a0a;
                                                          font-family: Helvetica,
                                                            Arial, sans-serif;
                                                          font-size: 10px;
                                                          font-weight: 400;
                                                          hyphens: auto;
                                                          line-height: 10px;
                                                          margin: 0;
                                                          mso-line-height-rule: exactly;
                                                          padding-bottom: 0;
                                                          padding-left: 0;
                                                          padding-right: 0;
                                                          padding-top: 0;
                                                          text-align: left;
                                                          vertical-align: top;
                                                          word-wrap: break-word;
                                                        "
                                                      >
                                                        &nbsp;
                                                      </td>
                                                    </tr>
                                                  </tbody>
                                                </table>
                                              </td>
                                            </tr>
                                            <tr
                                              style="
                                                padding-bottom: 0;
                                                padding-left: 0;
                                                padding-right: 0;
                                                padding-top: 0;
                                                text-align: left;
                                                vertical-align: top;
                                              "
                                            >
                                              <td
                                                style="
                                                  -moz-hyphens: auto;
                                                  -webkit-hyphens: auto;
                                                  margin: 0;
                                                  border-collapse: collapse !important;
                                                  color: #7c7c7c;
                                                  font-family: Helvetica, Arial,
                                                    sans-serif;
                                                  font-size: 16px;
                                                  font-weight: 400;
                                                  hyphens: auto;
                                                  line-height: 1.3;
                                                  margin: 0;
                                                  padding-bottom: 0;
                                                  padding-left: 0;
                                                  padding-right: 0;
                                                  padding-top: 0;
                                                  text-align: left;
                                                  vertical-align: top;
                                                  width: 40%;
                                                  word-wrap: break-word;
                                                "
                                              >
                                                <table
                                                  class="spacer"
                                                  style="
                                                    border-collapse: collapse;
                                                    border-spacing: 0;
                                                    padding-bottom: 0;
                                                    padding-left: 0;
                                                    padding-right: 0;
                                                    padding-top: 0;
                                                    text-align: left;
                                                    vertical-align: top;
                                                    width: 100%;
                                                  "
                                                >
                                                  <tbody>
                                                    <tr
                                                      style="
                                                        padding-bottom: 0;
                                                        padding-left: 0;
                                                        padding-right: 0;
                                                        padding-top: 0;
                                                        text-align: left;
                                                        vertical-align: top;
                                                      "
                                                    >
                                                      <td
                                                        height="10"
                                                        style="
                                                          -moz-hyphens: auto;
                                                          -webkit-hyphens: auto;
                                                          margin: 0;
                                                          border-collapse: collapse !important;
                                                          color: #0a0a0a;
                                                          font-family: Helvetica,
                                                            Arial, sans-serif;
                                                          font-size: 10px;
                                                          font-weight: 400;
                                                          hyphens: auto;
                                                          line-height: 10px;
                                                          margin: 0;
                                                          mso-line-height-rule: exactly;
                                                          padding-bottom: 0;
                                                          padding-left: 0;
                                                          padding-right: 0;
                                                          padding-top: 0;
                                                          text-align: left;
                                                          vertical-align: top;
                                                          word-wrap: break-word;
                                                        "
                                                      >
                                                        &nbsp;
                                                      </td>
                                                    </tr>
                                                  </tbody>
                                                </table>
                                                Teléfono:
                                                <table
                                                  class="spacer"
                                                  style="
                                                    border-collapse: collapse;
                                                    border-spacing: 0;
                                                    padding-bottom: 0;
                                                    padding-left: 0;
                                                    padding-right: 0;
                                                    padding-top: 0;
                                                    text-align: left;
                                                    vertical-align: top;
                                                    width: 100%;
                                                  "
                                                >
                                                  <tbody>
                                                    <tr
                                                      style="
                                                        padding-bottom: 0;
                                                        padding-left: 0;
                                                        padding-right: 0;
                                                        padding-top: 0;
                                                        text-align: left;
                                                        vertical-align: top;
                                                      "
                                                    >
                                                      <td
                                                        height="10"
                                                        style="
                                                          -moz-hyphens: auto;
                                                          -webkit-hyphens: auto;
                                                          margin: 0;
                                                          border-collapse: collapse !important;
                                                          color: #0a0a0a;
                                                          font-family: Helvetica,
                                                            Arial, sans-serif;
                                                          font-size: 10px;
                                                          font-weight: 400;
                                                          hyphens: auto;
                                                          line-height: 10px;
                                                          margin: 0;
                                                          mso-line-height-rule: exactly;
                                                          padding-bottom: 0;
                                                          padding-left: 0;
                                                          padding-right: 0;
                                                          padding-top: 0;
                                                          text-align: left;
                                                          vertical-align: top;
                                                          word-wrap: break-word;
                                                        "
                                                      >
                                                        &nbsp;
                                                      </td>
                                                    </tr>
                                                  </tbody>
                                                </table>
                                              </td>
                                              <td
                                                style="
                                                  -moz-hyphens: auto;
                                                  -webkit-hyphens: auto;
                                                  margin: 0;
                                                  border-collapse: collapse !important;
                                                  color: #0a0a0a;
                                                  font-family: Helvetica, Arial,
                                                    sans-serif;
                                                  font-size: 16px;
                                                  font-weight: 400;
                                                  hyphens: auto;
                                                  line-height: 1.3;
                                                  margin: 0;
                                                  padding-bottom: 0;
                                                  padding-left: 0;
                                                  padding-right: 0;
                                                  padding-top: 0;
                                                  text-align: left;
                                                  vertical-align: top;
                                                  word-wrap: break-word;
                                                "
                                              >
                                                <table
                                                  class="spacer"
                                                  style="
                                                    border-collapse: collapse;
                                                    border-spacing: 0;
                                                    padding-bottom: 0;
                                                    padding-left: 0;
                                                    padding-right: 0;
                                                    padding-top: 0;
                                                    text-align: left;
                                                    vertical-align: top;
                                                    width: 100%;
                                                  "
                                                >
                                                  <tbody>
                                                    <tr
                                                      style="
                                                        padding-bottom: 0;
                                                        padding-left: 0;
                                                        padding-right: 0;
                                                        padding-top: 0;
                                                        text-align: left;
                                                        vertical-align: top;
                                                      "
                                                    >
                                                      <td
                                                        height="10"
                                                        style="
                                                          -moz-hyphens: auto;
                                                          -webkit-hyphens: auto;
                                                          margin: 0;
                                                          border-collapse: collapse !important;
                                                          color: #0a0a0a;
                                                          font-family: Helvetica,
                                                            Arial, sans-serif;
                                                          font-size: 10px;
                                                          font-weight: 400;
                                                          hyphens: auto;
                                                          line-height: 10px;
                                                          margin: 0;
                                                          mso-line-height-rule: exactly;
                                                          padding-bottom: 0;
                                                          padding-left: 0;
                                                          padding-right: 0;
                                                          padding-top: 0;
                                                          text-align: left;
                                                          vertical-align: top;
                                                          word-wrap: break-word;
                                                        "
                                                      >
                                                        &nbsp;
                                                      </td>
                                                    </tr>
                                                  </tbody>
                                                </table>
                                                <strong>{{
                                                  page.data.lead.advisor_rel
                                                    .mobile_masked
                                                }}</strong>
                                                <table
                                                  class="spacer"
                                                  style="
                                                    border-collapse: collapse;
                                                    border-spacing: 0;
                                                    padding-bottom: 0;
                                                    padding-left: 0;
                                                    padding-right: 0;
                                                    padding-top: 0;
                                                    text-align: left;
                                                    vertical-align: top;
                                                    width: 100%;
                                                  "
                                                >
                                                  <tbody>
                                                    <tr
                                                      style="
                                                        padding-bottom: 0;
                                                        padding-left: 0;
                                                        padding-right: 0;
                                                        padding-top: 0;
                                                        text-align: left;
                                                        vertical-align: top;
                                                      "
                                                    >
                                                      <td
                                                        height="10"
                                                        style="
                                                          -moz-hyphens: auto;
                                                          -webkit-hyphens: auto;
                                                          margin: 0;
                                                          border-collapse: collapse !important;
                                                          color: #0a0a0a;
                                                          font-family: Helvetica,
                                                            Arial, sans-serif;
                                                          font-size: 10px;
                                                          font-weight: 400;
                                                          hyphens: auto;
                                                          line-height: 10px;
                                                          margin: 0;
                                                          mso-line-height-rule: exactly;
                                                          padding-bottom: 0;
                                                          padding-left: 0;
                                                          padding-right: 0;
                                                          padding-top: 0;
                                                          text-align: left;
                                                          vertical-align: top;
                                                          word-wrap: break-word;
                                                        "
                                                      >
                                                        &nbsp;
                                                      </td>
                                                    </tr>
                                                  </tbody>
                                                </table>
                                              </td>
                                            </tr>
                                            <tr
                                              style="
                                                padding-bottom: 0;
                                                padding-left: 0;
                                                padding-right: 0;
                                                padding-top: 0;
                                                text-align: left;
                                                vertical-align: top;
                                              "
                                            >
                                              <td
                                                style="
                                                  -moz-hyphens: auto;
                                                  -webkit-hyphens: auto;
                                                  margin: 0;
                                                  border-collapse: collapse !important;
                                                  color: #7c7c7c;
                                                  font-family: Helvetica, Arial,
                                                    sans-serif;
                                                  font-size: 16px;
                                                  font-weight: 400;
                                                  hyphens: auto;
                                                  line-height: 1.3;
                                                  margin: 0;
                                                  padding-bottom: 0;
                                                  padding-left: 0;
                                                  padding-right: 0;
                                                  padding-top: 0;
                                                  text-align: left;
                                                  vertical-align: top;
                                                  width: 40%;
                                                  word-wrap: break-word;
                                                "
                                              >
                                                <table
                                                  class="spacer"
                                                  style="
                                                    border-collapse: collapse;
                                                    border-spacing: 0;
                                                    padding-bottom: 0;
                                                    padding-left: 0;
                                                    padding-right: 0;
                                                    padding-top: 0;
                                                    text-align: left;
                                                    vertical-align: top;
                                                    width: 100%;
                                                  "
                                                >
                                                  <tbody>
                                                    <tr
                                                      style="
                                                        padding-bottom: 0;
                                                        padding-left: 0;
                                                        padding-right: 0;
                                                        padding-top: 0;
                                                        text-align: left;
                                                        vertical-align: top;
                                                      "
                                                    >
                                                      <td
                                                        height="10"
                                                        style="
                                                          -moz-hyphens: auto;
                                                          -webkit-hyphens: auto;
                                                          margin: 0;
                                                          border-collapse: collapse !important;
                                                          color: #0a0a0a;
                                                          font-family: Helvetica,
                                                            Arial, sans-serif;
                                                          font-size: 10px;
                                                          font-weight: 400;
                                                          hyphens: auto;
                                                          line-height: 10px;
                                                          margin: 0;
                                                          mso-line-height-rule: exactly;
                                                          padding-bottom: 0;
                                                          padding-left: 0;
                                                          padding-right: 0;
                                                          padding-top: 0;
                                                          text-align: left;
                                                          vertical-align: top;
                                                          word-wrap: break-word;
                                                        "
                                                      >
                                                        &nbsp;
                                                      </td>
                                                    </tr>
                                                  </tbody>
                                                </table>
                                                Email:
                                                <table
                                                  class="spacer"
                                                  style="
                                                    border-collapse: collapse;
                                                    border-spacing: 0;
                                                    padding-bottom: 0;
                                                    padding-left: 0;
                                                    padding-right: 0;
                                                    padding-top: 0;
                                                    text-align: left;
                                                    vertical-align: top;
                                                    width: 100%;
                                                  "
                                                >
                                                  <tbody>
                                                    <tr
                                                      style="
                                                        padding-bottom: 0;
                                                        padding-left: 0;
                                                        padding-right: 0;
                                                        padding-top: 0;
                                                        text-align: left;
                                                        vertical-align: top;
                                                      "
                                                    >
                                                      <td
                                                        height="10"
                                                        style="
                                                          -moz-hyphens: auto;
                                                          -webkit-hyphens: auto;
                                                          margin: 0;
                                                          border-collapse: collapse !important;
                                                          color: #0a0a0a;
                                                          font-family: Helvetica,
                                                            Arial, sans-serif;
                                                          font-size: 10px;
                                                          font-weight: 400;
                                                          hyphens: auto;
                                                          line-height: 10px;
                                                          margin: 0;
                                                          mso-line-height-rule: exactly;
                                                          padding-bottom: 0;
                                                          padding-left: 0;
                                                          padding-right: 0;
                                                          padding-top: 0;
                                                          text-align: left;
                                                          vertical-align: top;
                                                          word-wrap: break-word;
                                                        "
                                                      >
                                                        &nbsp;
                                                      </td>
                                                    </tr>
                                                  </tbody>
                                                </table>
                                              </td>
                                              <td
                                                style="
                                                  -moz-hyphens: auto;
                                                  -webkit-hyphens: auto;
                                                  margin: 0;
                                                  border-collapse: collapse !important;
                                                  color: #0a0a0a;
                                                  font-family: Helvetica, Arial,
                                                    sans-serif;
                                                  font-size: 16px;
                                                  font-weight: 400;
                                                  hyphens: auto;
                                                  line-height: 1.3;
                                                  margin: 0;
                                                  padding-bottom: 0;
                                                  padding-left: 0;
                                                  padding-right: 0;
                                                  padding-top: 0;
                                                  text-align: left;
                                                  vertical-align: top;
                                                  word-wrap: break-word;
                                                "
                                              >
                                                <table
                                                  class="spacer"
                                                  style="
                                                    border-collapse: collapse;
                                                    border-spacing: 0;
                                                    padding-bottom: 0;
                                                    padding-left: 0;
                                                    padding-right: 0;
                                                    padding-top: 0;
                                                    text-align: left;
                                                    vertical-align: top;
                                                    width: 100%;
                                                  "
                                                >
                                                  <tbody>
                                                    <tr
                                                      style="
                                                        padding-bottom: 0;
                                                        padding-left: 0;
                                                        padding-right: 0;
                                                        padding-top: 0;
                                                        text-align: left;
                                                        vertical-align: top;
                                                      "
                                                    >
                                                      <td
                                                        height="10"
                                                        style="
                                                          -moz-hyphens: auto;
                                                          -webkit-hyphens: auto;
                                                          margin: 0;
                                                          border-collapse: collapse !important;
                                                          color: #0a0a0a;
                                                          font-family: Helvetica,
                                                            Arial, sans-serif;
                                                          font-size: 10px;
                                                          font-weight: 400;
                                                          hyphens: auto;
                                                          line-height: 10px;
                                                          margin: 0;
                                                          mso-line-height-rule: exactly;
                                                          padding-bottom: 0;
                                                          padding-left: 0;
                                                          padding-right: 0;
                                                          padding-top: 0;
                                                          text-align: left;
                                                          vertical-align: top;
                                                          word-wrap: break-word;
                                                        "
                                                      >
                                                        &nbsp;
                                                      </td>
                                                    </tr>
                                                  </tbody>
                                                </table>
                                                <strong>{{
                                                  page.data.lead.advisor_rel
                                                    .email
                                                }}</strong>
                                                <table
                                                  class="spacer"
                                                  style="
                                                    border-collapse: collapse;
                                                    border-spacing: 0;
                                                    padding-bottom: 0;
                                                    padding-left: 0;
                                                    padding-right: 0;
                                                    padding-top: 0;
                                                    text-align: left;
                                                    vertical-align: top;
                                                    width: 100%;
                                                  "
                                                >
                                                  <tbody>
                                                    <tr
                                                      style="
                                                        padding-bottom: 0;
                                                        padding-left: 0;
                                                        padding-right: 0;
                                                        padding-top: 0;
                                                        text-align: left;
                                                        vertical-align: top;
                                                      "
                                                    >
                                                      <td
                                                        height="10"
                                                        style="
                                                          -moz-hyphens: auto;
                                                          -webkit-hyphens: auto;
                                                          margin: 0;
                                                          border-collapse: collapse !important;
                                                          color: #0a0a0a;
                                                          font-family: Helvetica,
                                                            Arial, sans-serif;
                                                          font-size: 10px;
                                                          font-weight: 400;
                                                          hyphens: auto;
                                                          line-height: 10px;
                                                          margin: 0;
                                                          mso-line-height-rule: exactly;
                                                          padding-bottom: 0;
                                                          padding-left: 0;
                                                          padding-right: 0;
                                                          padding-top: 0;
                                                          text-align: left;
                                                          vertical-align: top;
                                                          word-wrap: break-word;
                                                        "
                                                      >
                                                        &nbsp;
                                                      </td>
                                                    </tr>
                                                  </tbody>
                                                </table>
                                              </td>
                                            </tr>
                                          </table>
                                        </th>
                                        <th
                                          class="expander"
                                          style="
                                            -moz-hyphens: auto;
                                            -webkit-hyphens: auto;
                                            margin: 0;
                                            border-collapse: collapse !important;
                                            color: #0a0a0a;
                                            font-family: Helvetica, Arial,
                                              sans-serif;
                                            font-size: 16px;
                                            font-weight: 400;
                                            hyphens: auto;
                                            line-height: 1.3;
                                            margin: 0;
                                            padding: 0 !important;
                                            padding-bottom: 0;
                                            padding-left: 0;
                                            padding-right: 0;
                                            padding-top: 0;
                                            text-align: left;
                                            vertical-align: top;
                                            visibility: hidden;
                                            width: 0;
                                            word-wrap: break-word;
                                          "
                                        ></th>
                                      </tr>
                                    </tbody>
                                  </table>
                                </th>
                              </tr>
                            </tbody>
                          </table>
                          <table
                            class="spacer"
                            style="
                              border-collapse: collapse;
                              border-spacing: 0;
                              padding-bottom: 0;
                              padding-left: 0;
                              padding-right: 0;
                              padding-top: 0;
                              text-align: left;
                              vertical-align: top;
                              width: 100%;
                            "
                          >
                            <tbody>
                              <tr
                                style="
                                  padding-bottom: 0;
                                  padding-left: 0;
                                  padding-right: 0;
                                  padding-top: 0;
                                  text-align: left;
                                  vertical-align: top;
                                "
                              >
                                <td
                                  height="24"
                                  style="
                                    -moz-hyphens: auto;
                                    -webkit-hyphens: auto;
                                    margin: 0;
                                    border-collapse: collapse !important;
                                    color: #0a0a0a;
                                    font-family: Helvetica, Arial, sans-serif;
                                    font-size: 24px;
                                    font-weight: 400;
                                    hyphens: auto;
                                    line-height: 24px;
                                    margin: 0;
                                    mso-line-height-rule: exactly;
                                    padding-bottom: 0;
                                    padding-left: 0;
                                    padding-right: 0;
                                    padding-top: 0;
                                    text-align: left;
                                    vertical-align: top;
                                    word-wrap: break-word;
                                  "
                                >
                                  &nbsp;
                                </td>
                              </tr>
                            </tbody>
                          </table>
                          <table
                            class="row"
                            style="
                              max-width: 600px;
                              border-collapse: collapse;
                              border-spacing: 0;
                              display: table;
                              padding: 0;
                              padding-bottom: 0;
                              padding-left: 0;
                              padding-right: 0;
                              padding-top: 0;
                              position: relative;
                              text-align: left;
                              vertical-align: top;
                              width: 100%;
                            "
                          >
                            <tbody>
                              <tr
                                style="
                                  padding-bottom: 0;
                                  padding-left: 0;
                                  padding-right: 0;
                                  padding-top: 0;
                                  text-align: left;
                                  vertical-align: top;
                                "
                              >
                                <th
                                  class="small-12 large-12 columns first last"
                                  style="
                                    -moz-hyphens: auto;
                                    -webkit-hyphens: auto;
                                    margin: 0 auto;
                                    border-collapse: collapse !important;
                                    color: #0a0a0a;
                                    font-family: Helvetica, Arial, sans-serif;
                                    font-size: 16px;
                                    font-weight: 400;
                                    hyphens: auto;
                                    line-height: 1.3;
                                    margin: 0 auto;
                                    padding-bottom: 16px;
                                    padding-left: 30px;
                                    padding-right: 30px;
                                    padding-top: 0;
                                    text-align: left;
                                    vertical-align: top;
                                    width: 550px;
                                    word-wrap: break-word;
                                  "
                                >
                                  <table
                                    style="
                                      border-collapse: collapse;
                                      border-spacing: 0;
                                      padding-bottom: 0;
                                      padding-left: 0;
                                      padding-right: 0;
                                      padding-top: 0;
                                      text-align: left;
                                      vertical-align: top;
                                      width: 100%;
                                    "
                                  >
                                    <tbody>
                                      <tr
                                        style="
                                          padding-bottom: 0;
                                          padding-left: 0;
                                          padding-right: 0;
                                          padding-top: 0;
                                          text-align: left;
                                          vertical-align: top;
                                        "
                                      >
                                        <th
                                          style="
                                            -moz-hyphens: auto;
                                            -webkit-hyphens: auto;
                                            margin: 0;
                                            border-collapse: collapse !important;
                                            color: #0a0a0a;
                                            font-family: Helvetica, Arial,
                                              sans-serif;
                                            font-size: 16px;
                                            font-weight: 400;
                                            hyphens: auto;
                                            line-height: 1.3;
                                            margin: 0;
                                            padding-bottom: 0;
                                            padding-left: 0;
                                            padding-right: 0;
                                            padding-top: 0;
                                            text-align: left;
                                            vertical-align: top;
                                            word-wrap: break-word;
                                          "
                                        >
                                          <!--<center
                                            style="min-width: 490px; width: 100%"
                                          >-->
                                          <center style="width: 100%">
                                            <table
                                              class="button large success float-center"
                                              style="
                                                margin: 0 0 16px 0;
                                                border-collapse: collapse;
                                                border-spacing: 0;
                                                float: none;
                                                margin: 0 0 16px 0;
                                                padding-bottom: 0;
                                                padding-left: 0;
                                                padding-right: 0;
                                                padding-top: 0;
                                                text-align: center;
                                                vertical-align: top;
                                                width: auto;
                                              "
                                            >
                                              <tbody>
                                                <tr
                                                  style="
                                                    padding-bottom: 0;
                                                    padding-left: 0;
                                                    padding-right: 0;
                                                    padding-top: 0;
                                                    text-align: left;
                                                    vertical-align: top;
                                                  "
                                                >
                                                  <td
                                                    style="
                                                      -moz-hyphens: auto;
                                                      -webkit-hyphens: auto;
                                                      margin: 0;
                                                      border-collapse: collapse !important;
                                                      color: #0a0a0a;
                                                      font-family: Helvetica,
                                                        Arial, sans-serif;
                                                      font-size: 16px;
                                                      font-weight: 400;
                                                      hyphens: auto;
                                                      line-height: 1.3;
                                                      margin: 0;
                                                      padding-bottom: 0;
                                                      padding-left: 0;
                                                      padding-right: 0;
                                                      padding-top: 0;
                                                      text-align: left;
                                                      vertical-align: top;
                                                      word-wrap: break-word;
                                                    "
                                                  >
                                                    <table
                                                      style="
                                                        border-collapse: collapse;
                                                        border-spacing: 0;
                                                        padding-bottom: 0;
                                                        padding-left: 0;
                                                        padding-right: 0;
                                                        padding-top: 0;
                                                        text-align: left;
                                                        vertical-align: top;
                                                        width: 100%;
                                                      "
                                                    >
                                                      <tbody>
                                                        <tr
                                                          style="
                                                            padding-bottom: 0;
                                                            padding-left: 0;
                                                            padding-right: 0;
                                                            padding-top: 0;
                                                            text-align: left;
                                                            vertical-align: top;
                                                          "
                                                        >
                                                          <td
                                                            style="
                                                              -moz-hyphens: auto;
                                                              -webkit-hyphens: auto;
                                                              margin: 0;
                                                              background: #25d366;
                                                              border: 0 solid
                                                                #25d366;
                                                              border-collapse: collapse !important;
                                                              color: #fefefe;
                                                              font-family: Helvetica,
                                                                Arial,
                                                                sans-serif;
                                                              font-size: 16px;
                                                              font-weight: 400;
                                                              hyphens: auto;
                                                              line-height: 1.3;
                                                              margin: 0;
                                                              padding-bottom: 0;
                                                              padding-left: 0;
                                                              padding-right: 0;
                                                              padding-top: 0;
                                                              text-align: left;
                                                              vertical-align: top;
                                                              word-wrap: break-word;
                                                            "
                                                          >
                                                            <a
                                                              style="
                                                                border: 0 solid
                                                                  #25d366;
                                                                border-radius: 3px;
                                                                color: #fefefe;
                                                                display: inline-block;
                                                                font-family: Helvetica,
                                                                  Arial,
                                                                  sans-serif;
                                                                font-size: 16px;
                                                                font-weight: 700;
                                                                line-height: 1.3;
                                                                padding: 10px
                                                                  20px 10px 20px;
                                                                text-align: left;
                                                                text-decoration: none;
                                                              "
                                                              align="center"
                                                              :href="
                                                                'https://api.whatsapp.com/send?phone=51' +
                                                                page.data.lead
                                                                  .advisor_rel
                                                                  .mobile
                                                              "
                                                              target="_blank"
                                                              >Contacta a tu
                                                              Asesor</a
                                                            >
                                                          </td>
                                                        </tr>
                                                      </tbody>
                                                    </table>
                                                  </td>
                                                </tr>
                                              </tbody>
                                            </table>
                                          </center>
                                        </th>
                                        <th
                                          class="expander"
                                          style="
                                            -moz-hyphens: auto;
                                            -webkit-hyphens: auto;
                                            margin: 0;
                                            border-collapse: collapse !important;
                                            color: #0a0a0a;
                                            font-family: Helvetica, Arial,
                                              sans-serif;
                                            font-size: 16px;
                                            font-weight: 400;
                                            hyphens: auto;
                                            line-height: 1.3;
                                            margin: 0;
                                            padding: 0 !important;
                                            padding-bottom: 0;
                                            padding-left: 0;
                                            padding-right: 0;
                                            padding-top: 0;
                                            text-align: left;
                                            vertical-align: top;
                                            visibility: hidden;
                                            width: 0;
                                            word-wrap: break-word;
                                          "
                                        ></th>
                                      </tr>
                                    </tbody>
                                  </table>

                                  <table
                                    style="
                                      margin-top: 50px;
                                      border-collapse: collapse;
                                      border-spacing: 0;
                                      padding-bottom: 0;
                                      padding-left: 0;
                                      padding-right: 0;
                                      padding-top: 0;
                                      text-align: left;
                                      vertical-align: top;
                                      width: 100%;
                                    "
                                  >
                                    <tbody>
                                      <tr
                                        style="
                                          padding-bottom: 0;
                                          padding-left: 0;
                                          padding-right: 0;
                                          padding-top: 0;
                                          text-align: left;
                                          vertical-align: top;
                                        "
                                      >
                                        <th
                                          style="
                                            -moz-hyphens: auto;
                                            -webkit-hyphens: auto;
                                            margin: 0;
                                            border-collapse: collapse !important;
                                            color: #0a0a0a;
                                            font-family: Helvetica, Arial,
                                              sans-serif;
                                            font-size: 16px;
                                            font-weight: 400;
                                            hyphens: auto;
                                            line-height: 1.3;
                                            margin: 0;
                                            padding-bottom: 0;
                                            padding-left: 0;
                                            padding-right: 0;
                                            padding-top: 0;
                                            text-align: left;
                                            vertical-align: top;
                                            word-wrap: break-word;
                                          "
                                        >
                                          <!--<center
                                            style="min-width: 490px; width: 100%"
                                          >-->
                                          <center style="width: 100%">
                                            <table
                                              class="button large success float-center"
                                              style="
                                                margin: 0 0 16px 0;
                                                border-collapse: collapse;
                                                border-spacing: 0;
                                                float: none;
                                                margin: 0 0 16px 0;
                                                padding-bottom: 0;
                                                padding-left: 0;
                                                padding-right: 0;
                                                padding-top: 0;
                                                text-align: left;
                                                vertical-align: top;
                                                width: 100%;
                                              "
                                            >
                                              <tbody>
                                                <tr
                                                  style="
                                                    padding-bottom: 0;
                                                    padding-left: 0;
                                                    padding-right: 0;
                                                    padding-top: 0;
                                                    text-align: left;
                                                    vertical-align: top;
                                                  "
                                                >
                                                  <td
                                                    style="
                                                      -moz-hyphens: auto;
                                                      -webkit-hyphens: auto;
                                                      margin: 0;
                                                      border-collapse: collapse !important;
                                                      color: #0a0a0a;
                                                      font-family: Helvetica,
                                                        Arial, sans-serif;
                                                      font-size: 16px;
                                                      font-weight: 400;
                                                      hyphens: auto;
                                                      line-height: 1.3;
                                                      margin: 0;
                                                      padding-bottom: 0;
                                                      padding-left: 0;
                                                      padding-right: 0;
                                                      padding-top: 0;
                                                      text-align: left;
                                                      vertical-align: top;
                                                      word-wrap: break-word;
                                                    "
                                                  >
                                                    <table
                                                      style="
                                                        border-collapse: collapse;
                                                        border-spacing: 0;
                                                        padding-bottom: 0;
                                                        padding-left: 0;
                                                        padding-right: 0;
                                                        padding-top: 0;
                                                        text-align: left;
                                                        vertical-align: top;
                                                        width: 100%;
                                                      "
                                                    >
                                                      <tbody>
                                                        <tr
                                                          style="
                                                            padding-bottom: 0;
                                                            padding-left: 0;
                                                            padding-right: 0;
                                                            padding-top: 0;
                                                            text-align: left;
                                                            vertical-align: top;
                                                          "
                                                        >
                                                          <td
                                                            style="
                                                              -moz-hyphens: auto;
                                                              -webkit-hyphens: auto;
                                                              margin: 0;
                                                              border-collapse: collapse !important;
                                                              color: #fefefe;
                                                              font-family: Helvetica,
                                                                Arial,
                                                                sans-serif;
                                                              font-size: 16px;
                                                              font-weight: 400;
                                                              hyphens: auto;
                                                              line-height: 1.3;
                                                              margin: 0;
                                                              padding-bottom: 0;
                                                              padding-left: 0;
                                                              padding-right: 0;
                                                              padding-top: 0;
                                                              text-align: left;
                                                              vertical-align: top;
                                                              word-wrap: break-word;
                                                            "
                                                          >
                                                            <p
                                                              data-v-5bed4363=""
                                                              style="
                                                                margin: 0px 0px
                                                                  10px;
                                                                color: rgb(
                                                                  10,
                                                                  10,
                                                                  10
                                                                );
                                                                font-size: 16px;
                                                                font-weight: 400;
                                                                line-height: 1.3;
                                                                padding: 0px;
                                                                text-align: left;
                                                              "
                                                            >
                                                              *Esta cotización
                                                              fue enviada a tu
                                                              correo electrónico
                                                            </p>
                                                          </td>
                                                        </tr>
                                                      </tbody>
                                                    </table>
                                                  </td>
                                                </tr>
                                              </tbody>
                                            </table>
                                          </center>
                                        </th>
                                        <th
                                          class="expander"
                                          style="
                                            -moz-hyphens: auto;
                                            -webkit-hyphens: auto;
                                            margin: 0;
                                            border-collapse: collapse !important;
                                            color: #0a0a0a;
                                            font-family: Helvetica, Arial,
                                              sans-serif;
                                            font-size: 16px;
                                            font-weight: 400;
                                            hyphens: auto;
                                            line-height: 1.3;
                                            margin: 0;
                                            padding: 0 !important;
                                            padding-bottom: 0;
                                            padding-left: 0;
                                            padding-right: 0;
                                            padding-top: 0;
                                            text-align: left;
                                            vertical-align: top;
                                            visibility: hidden;
                                            width: 0;
                                            word-wrap: break-word;
                                          "
                                        ></th>
                                      </tr>
                                    </tbody>
                                  </table>
                                </th>
                              </tr>
                            </tbody>
                          </table>
                          <table
                            class="spacer"
                            style="
                              border-collapse: collapse;
                              border-spacing: 0;
                              padding-bottom: 0;
                              padding-left: 0;
                              padding-right: 0;
                              padding-top: 0;
                              text-align: left;
                              vertical-align: top;
                              width: 100%;
                            "
                          >
                            <tbody>
                              <tr
                                style="
                                  padding-bottom: 0;
                                  padding-left: 0;
                                  padding-right: 0;
                                  padding-top: 0;
                                  text-align: left;
                                  vertical-align: top;
                                "
                              >
                                <td
                                  height="32"
                                  style="
                                    -moz-hyphens: auto;
                                    -webkit-hyphens: auto;
                                    margin: 0;
                                    border-collapse: collapse !important;
                                    color: #0a0a0a;
                                    font-family: Helvetica, Arial, sans-serif;
                                    font-size: 32px;
                                    font-weight: 400;
                                    hyphens: auto;
                                    line-height: 32px;
                                    margin: 0;
                                    mso-line-height-rule: exactly;
                                    padding-bottom: 0;
                                    padding-left: 0;
                                    padding-right: 0;
                                    padding-top: 0;
                                    text-align: left;
                                    vertical-align: top;
                                    word-wrap: break-word;
                                  "
                                >
                                  &nbsp;
                                </td>
                              </tr>
                            </tbody>
                          </table>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                  <table
                    align="center"
                    class="spacer float-center"
                    style="
                      margin: 0 auto;
                      border-collapse: collapse;
                      border-spacing: 0;
                      float: none;
                      margin: 0 auto;
                      padding-bottom: 0;
                      padding-left: 0;
                      padding-right: 0;
                      padding-top: 0;
                      text-align: center;
                      vertical-align: top;
                      width: 100%;
                    "
                  >
                    <tbody>
                      <tr
                        style="
                          padding-bottom: 0;
                          padding-left: 0;
                          padding-right: 0;
                          padding-top: 0;
                          text-align: left;
                          vertical-align: top;
                        "
                      >
                        <td
                          height="32"
                          style="
                            -moz-hyphens: auto;
                            -webkit-hyphens: auto;
                            margin: 0;
                            border-collapse: collapse !important;
                            color: #0a0a0a;
                            font-family: Helvetica, Arial, sans-serif;
                            font-size: 32px;
                            font-weight: 400;
                            hyphens: auto;
                            line-height: 32px;
                            margin: 0;
                            mso-line-height-rule: exactly;
                            padding-bottom: 0;
                            padding-left: 0;
                            padding-right: 0;
                            padding-top: 0;
                            text-align: left;
                            vertical-align: top;
                            word-wrap: break-word;
                          "
                        >
                          &nbsp;
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </center>
              </td>
            </tr>
          </table>
          <!-- prevent Gmail on iOS font size manipulation -->
          <div
            style="
              display: none;
              white-space: nowrap;
              font: 15px courier;
              line-height: 0;
            "
          >
            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
            &nbsp; &nbsp; &nbsp;
          </div>
        </div>
      </div>
    </client-only>
  </div>
</template>
<script>
export default {
  watchQuery: true,
  nuxtI18n: {
    paths: {
      en: "/quotation",
      es: "/cotizacion",
    },
  },
  data() {
    return {
      storageUrl: process.env.STORAGE_URL,
      lead: {
        project_rel: {
          projectTypeDepartmentRel: {},
          status_rel: {},
          statusRel: {},
          financing_options_rel: {},
        },
        projectRel: {
          status_rel: {},
          financing_options_rel: {},
          statusRel: {},
        },
      },
      page: {},
    };
  },
  async validate({ route, $axios, app }) {
    const data = await $axios.$get("/api/page/quotation", {
      params: { ...(route.query.id ? { id: route.query.id } : {}) },
    });
    if (data.success) {
      return true;
    }
    return false;
  },
  async asyncData({ route, $axios, app }) {
    let { data } = await $axios.get("/api/page/quotation", {
      params: {
        ...(route.query.id ? { id: route.query.id } : {}),
      },
    });
    return { page: data };
  },
};
</script>
<style scoped>
@media only screen {
  /*html {
    min-height: 100%;
    background: #f9f9f9;
  }*/
  .wrapper_email {
    min-height: 100%;
    background: #f9f9f9;
  }
}

@media only screen and (max-width: 610px) {
  .small-float-center {
    margin: 0 auto !important;
    float: none !important;
    text-align: center !important;
  }
}

.inner-email {
  max-width: 600px;
  margin: auto;
  padding-top: 80px;
}

.container {
  width: 100% !important;
}

.callout-project {
  padding: 20px !important;
}

@media only screen and (max-width: 610px) {
  table.body img {
    width: auto;
    height: auto;
  }

  table.body center {
    min-width: 0 !important;
  }

  table.body .container {
    width: 95% !important;
  }

  table.body .columns {
    height: auto !important;
    -moz-box-sizing: border-box;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    padding-left: 30px !important;
    padding-right: 30px !important;
  }

  table.body .columns .columns {
    padding-left: 0 !important;
    padding-right: 0 !important;
  }

  table.body .collapse .columns {
    padding-left: 0 !important;
    padding-right: 0 !important;
  }

  th.small-6 {
    display: inline-block !important;
    width: 50% !important;
  }

  th.small-12 {
    display: inline-block !important;
    width: 100% !important;
  }

  .columns th.small-12 {
    display: block !important;
    width: 100% !important;
  }

  table.menu {
    width: 100% !important;
  }

  table.menu td,
  table.menu th {
    width: auto !important;
    display: inline-block !important;
  }

  table.menu.vertical td,
  table.menu.vertical th {
    display: block !important;
  }

  table.menu[align="center"] {
    width: auto !important;
  }
}
</style>